<script>
    document.addEventListener("DOMContentLoaded", function(event) {
        const showNavbar = (toggleId, navId, bodyId, headerId) => {
            const toggle = document.getElementById(toggleId),
                nav = document.getElementById(navId),
                bodypd = document.getElementById(bodyId),
                headerpd = document.getElementById(headerId);

            // Validate that all variables exist
            if (toggle && nav && bodypd && headerpd) {
                toggle.addEventListener("click", () => {
                    // show navbar
                    nav.classList.toggle("show");
                    // change icon
                    toggle.classList.toggle("bx-x");
                    // add padding to body
                    bodypd.classList.toggle("body-pd");
                    // add padding to header
                    headerpd.classList.toggle("body-pd");
                });
            }
        };

        showNavbar("header-toggle", "nav-bar", "body-pd", "header");

        /*===== LINK ACTIVE =====*/
        const linkColor = document.querySelectorAll(".nav_link");

        function colorLink() {
            if (linkColor) {
                linkColor.forEach((l) => l.classList.remove("active"));
                this.classList.add("active");
            }
        }
        linkColor.forEach((l) => l.addEventListener("click", colorLink));

        // Your code to run since DOM is loaded and ready
    });
</script>

<!-- JQUERY -->
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
crossorigin="anonymous"></script>
<!-- Toastr -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script> -->

<script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>


<script type="text/javascript" src="<?php echo e(asset('colorpciker/js/jquery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('colorpicker/js/colorpicker.js')); ?>"></script>

<script src="<?php echo e(asset('calender/moment.js')); ?>"></script>
<script src="<?php echo e(asset('calender/fullCal.js')); ?>"></script>


<script>
    $(document).ready(function() {

        // Show Hide password.
        $(".add_user_password #show_password").on("click", function() {
            if ($(this).prop("checked") == true) {
                $(".add_user_password #password").prop("type", "text");
            } else {
                $(".add_user_password #password").prop("type", "password");
            }
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('label.revinedd').hide();
        $('label.msg').hide();
        let user_id = $('input.user_id').val();
        let role_id = $('input.role_id').val();
        let events12 = [];
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('get_tasks_for_calender')); ?>",
            success: function(data) {
                var i = 0;
                data.forEach(function(value) {
                    var obj = new Object();
                    obj.id          =   value['id'];
                    obj.title       =   value['name'];
                    obj.start       =   value['created_at'];
                    obj.color       =   value['color'];
                    obj.className   =   'reg_selected';

                    events12[i++] = obj;
                    //$('#calendar').fullCalendar('renderEvent', obj, true);
                    //i++;
                    //$(".reg_selected").children('div.fc-content').find('span.fc-title:eq('+i+')').attr();
                  //console.log($(".reg_selected:eq("+i+")"));
                });
                console.log(events12);


                $('#calendar').fullCalendar({
                        header: {
                            left: 'prev,next today',
                            center: 'title',
                            right: 'month,agendaWeek,agendaDay'
                        },
                        defaultDate: '2021-11-01',
                        defaultView: 'month',
                        editable: true,
                        events: events12,
                        eventRender: function(event, element){
                            element.attr("data", event.id);
                            element.attr("color", event.color);
                        }
                    });
            }
        });

    });
</script>

<script>
    $(document).on('click', '.reg_selected', function() {
        let id = $(this).attr('data');
        let role_id = $('input.role_id').val();
        let text = "File Not Found";
        $.ajax({
            type: "GET",
            url: "<?php echo e(url('/get_task_detail_for_calender')); ?>" + "/" + id,
            success: function(data) {
                $('span.task_title').text('View: ' + data.name);
                $('span.view_task_label').css('color', data.color);
                $('span.view_task_label').text(data.status_name);
                $('span.deadline').text(data.deadline);
                $('span.desc').text(data.description);

                if(data.file != '' && typeof(data.file) != 'undefined'){
                    $('div.att').html(data.file);
                    $('a.download').show();
                    $('a.download').attr('href', "<?php echo e(url('/download_file_in_calender')); ?>" + "/" +
                    data.file);
                }else{
                    $('div.att').text("Attachment Not Found");
                    $('a.download').hide();
                }
                $('input.main_id').val(data.id);
                if (data.status_name == "approved") {
                  if(role_id == 1){
                    $('label.msg').show();
                    $('a.callRevine').hide();
                    $('a.approve').hide();
                    $('label.revinedd').hide();
                  }else{
                    $('a.progres').hide();
                    $('a.complete').hide();
                    $('label.msg').show();
                  }
                } else if (data.status_name == "completed") {
                    $('a.callRevine').show();
                    $('a.approve').show();
                    $('a.approve').attr('href', '<?php echo e(url("/approve_task_in_calender")); ?>' + "/" + data.color_id + "/" + data.id );
                    $('label.msg').hide();
                    $('label.revinedd').hide();

                }else if (data.status_name == "revined") {
                    $('a.callRevine').hide();
                    $('a.approve').hide();
                    $('label.msg').hide();
                    $('label.revinedd').show();
                }else if(data.status_name == "pending"){
                  if(role_id == 1){
                    $('label.revinedd').hide();
                  $('label.msg').hide();
                  $('a.callRevine').hide();
                  $('a.approve').hide();
                  }else{
                  $('a.progres').show();
                  $('a.complete').hide();
                  $('label.msg').hide();
                  }
                }
                $('#view_task_detail').modal('show');
            }
        });
    });
</script>

<script>
    $(document).on('click', '.callRevine', function() {
        $('#view_task_detail').modal('hide');

        $('#revine_task_modal').modal('show');
    });
</script>

<script>
    $(document).on("mouseover", ".reg_selected", function() {
        let task = $(this).children('div.fc-content');
        let color = $(this).attr('color');
        let title = task.find('span.fc-title').text();
        let date = task.find('span.fc-time').text();

        $(this).attr('title', 'Task Name: -' + title + ' ' + 'Date/Time: -' + date);
        $(".tooltip-inner").css({"background-color":color});
        $(".tooltip-arrow").removeClass();
        $(this).tooltip();
    });
</script>

<script>
    $(document).on('click','.fc-day-number',function(){
        let date = $(this).attr('data-date');
    });
</script>


<!-- Roles -->
<?php if(Session::has('role_success')): ?>
    <script>
        toastr.success("<?php echo e(Session::get('role_success')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('role_danger')): ?>
    <script>
        toastr.error("<?php echo e(Session::get('role_danger')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('role_info')): ?>
    <script>
        toastr.info("<?php echo e(Session::get('role_info')); ?>");
    </script>
<?php endif; ?>

<!-- Users -->
<?php if(Session::has('user_success')): ?>
    <script>
        toastr.success("<?php echo e(Session::get('user_success')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('user_info')): ?>
    <script>
        toastr.info("<?php echo e(Session::get('user_info')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('user_danger')): ?>
    <script>
        toastr.error("<?php echo e(Session::get('user_danger')); ?>");
    </script>
<?php endif; ?>

<!-- Projects -->
<?php if(Session::has('project_success')): ?>
    <script>
        toastr.success("<?php echo e(Session::get('project_success')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('project_info')): ?>
    <script>
        toastr.info("<?php echo e(Session::get('project_info')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('proejct_danger')): ?>
    <script>
        toastr.error("<?php echo e(Session::get('proejct_danger')); ?>");
    </script>
<?php endif; ?>

<!-- Tasks -->
<?php if(Session::has('task_success')): ?>
    <script>
        toastr.success("<?php echo e(Session::get('task_success')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('task_info')): ?>
    <script>
        toastr.info("<?php echo e(Session::get('task_info')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('task_warning')): ?>
    <script>
        toastr.error("<?php echo e(Session::get('task_warning')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('task_danger')): ?>
    <script>
        toastr.error("<?php echo e(Session::get('task_danger')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('colors')): ?>
    <script>
        alert("<?php echo e(Session::get('colors')); ?>");
    </script>
<?php endif; ?>

<?php if(Session::has('task_process')): ?>
    <script>
        alert("<?php echo e(Session::get('task_process')); ?>");
    </script>
<?php endif; ?>

<?php if($errors->any()): ?>
    <script>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.error("<?php echo e($error); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
<?php endif; ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\taskly\resources\views/layouts/footer.blade.php ENDPATH**/ ?>