<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="container mt-5 pt-5">
        <div class="row">
            <div class="col-12">
              <div class="d-flex justify-content-between">
                <h3>Comments</h3>
                <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($per == 11): ?>
                    <a href="<?php echo e(url('comment')); ?>" class="btn btn-success" style="box-shadow:0px 0px 3px lightgrey;">CREATE COMMENT</a>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </div>
            </div>
        </div>
        
        <br><br>
        
        <div class="row">
            <div class="col-12">
                
                <table id="comments_datatable" class="display">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Platform</th>
                            <th>URL</th>
                            <th>Type</th>
                            <th>Sender</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($comments->count() != 0): ?>
                            <?php $comment_no = 1; ?>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($comment_no++); ?></td>
                                    <td><?php echo e($comment->platform); ?></td>
                                    <td><?php echo e($comment->url); ?></td>
                                    <td><?php echo e($comment->comment_type); ?></td>
                                    <?php if($comment->first_name == ""): ?>
                                        <td>UNKNOWN</td>
                                    <?php else: ?>
                                        <td><?php echo e($comment->first_name); ?> <?php echo e($comment->last_name); ?></td>
                                    <?php endif; ?>
                                    <?php if($comment->color_id == 5): ?>
                                        <td style="color:<?php echo e($comment->status_color); ?>; font-weight:bold; text-transform:uppercase">Rejected</td>
                                    <?php else: ?>
                                        <td style="color:<?php echo e($comment->status_color); ?>; font-weight:bold; text-transform:uppercase"><?php echo e($comment->status_name); ?></td>
                                    <?php endif; ?>
                                    
                                    
                                    <td>
                                      <!-- View comment -->
                                      <a class="me-2 comment_view_trigger" data="<?php echo e($comment->id); ?>"><i class="fas fa-eye" style="color:black;"></i></a>
                                      <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($per == 9): ?> 
                                            <!-- Edit comment -->
                                            <?php if($comment->color_id == 1): ?>
                                                <a class="me-2 comment_edit_trigger" data="<?php echo e($comment->id); ?>"><i class="fas fa-edit"></i></a>  
                                            <?php endif; ?>
                                          
                                          <!-- Delete commment -->
                                          <a href="<?php echo e(route('delete-comment', ['id'=> $comment->id])); ?>" class="me-2"><i class="fas fa-trash" style="color:red;"></i></a>
                                        <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php else: ?>
                            <tr>
                                <td style="font-weight:bold; font-style:italic;">No comments found!</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>



<!-- View comment modal -->
<div class="modal" tabindex="-1" id="comment_view_modal">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(url('comment_approve')); ?>" method="POST" class="form comment_view_form">
        <?php echo csrf_field(); ?>

        <div class="modal-header">
          <h5 class="modal-title"></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
          <!-- Platform -->
          <div class="comment_view_data"><span class="label">Plateform:</span><span id="comment_view_platform"></span></div>
          <hr>
          <!-- URL -->
          <div class="comment_view_data"><span class="label">URL:</span><span id="comment_view_url"></span></div>
          <hr>
          <!-- Actual comment -->
          <div class="comment_view_data">
            <span class="label">Comment:</span>
            <p id="comment_view_actual_comment"></p>
          </div>
          <hr>
          <!-- Sedner -->
          <div class="comment_view_data"><span class="label">Sender:</span><span id="comment_view_sender"></span></div>
          <hr>
          <!-- Feedback -->
          <div class="">
            <span class="label">Feedback:</span>
            <?php if(Session::get("user")->role_id == 1): ?>
              <textarea name="feedback" id="comment_view_feedback" cols="30" rows="5" class="form-control"></textarea>
            <?php else: ?>
              <textarea name="feedback" id="comment_view_feedback" cols="30" rows="5" class="form-control" disabled></textarea>
            <?php endif; ?>
            
          </div>

          <input type="hidden" value="" id="id_in_view_comment_modal" name="comment_id">

        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
            <?php if(Session::get("user")->role_id == 1): ?>
              <a href="" class="btn btn-light reject" style="background-color:var(--revined-color); color:white;">Reject</a>   
              <input type="submit" class="btn btn-light approve" style="background-color:var(--approve-color); color:white;" value="Approve">
            <?php endif; ?>
        </div>

      </form>
    </div>
  </div>
</div>


<!-- Edit comment modal -->
<div class="modal" tabindex="-1" id="comment_edit_modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form action="<?php echo e(url('update-comment')); ?>" method="POST" class="form comment_update_form">
        <?php echo csrf_field(); ?>
        <div class="modal-body">

          <!-- Platform -->
          <div class="form-group mb-3">
            <input type="text" placeholder="Platform" id="edit_comment_platform" name="comment_platform" value="" class="form-control" disabled>
          </div>

          <!-- Url -->
          <div class="form-group mb-3">
            <input type="text" placeholder="URL" id="edit_comment_url" name="comment_url" value="" class="form-control" disabled>
          </div>

          <!-- Actual comment -->
          <div class="form-group mb-3">
            <textarea name="actual_comment" placeholder="Comment" id="edit_actual_comment" class="form-control" cols="30" rows="5" required></textarea>
          </div>

          <!-- Feedback -->
          <div class="form-group mb-3">
            <textarea name="feedback" placeholder="Feedback" id="edit_comment_feedback" class="form-control" cols="30" rows="5" required></textarea>
          </div>

          <!-- Comment type -->
          <div class="form-group mb-3">
            <input type="text" placeholder="Comment Type" id="edit_comment_type" name="comment_type" value="" class="form-control">
          </div>

          <!-- comment id -->
          <input type="hidden" name="id" id="comment_id_in_edit_modal" value="">
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-primary" value="Update">
        </div>

      </form>
    </div>
  </div>
</div>
<!-- edit modal ends -->
<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gbsprojects/public_html/taskmanagement/resources/views/commentingSystem/comments_view.blade.php ENDPATH**/ ?>