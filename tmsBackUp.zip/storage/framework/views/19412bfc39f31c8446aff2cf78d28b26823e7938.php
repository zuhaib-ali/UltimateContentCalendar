<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="container mt-5 pt-5">
<section id="second-container3">
        <div class="main-container-two">
            <div class="welcome-note-two">
                <h4>Clients (<?php echo e($projects->count()); ?>)</h4>
            </div>
            
            <div>
                <!-- Button trigger modal -->
                <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($per == 7): ?>
                    <button class="btn btn-success" data-bs-toggle="modal"  data-bs-target="#add_project" type="button">Create Client</button>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <!-- Modal -->
                <div class="modal fade" id="add_project" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="<?php echo e(route('add-project')); ?>" method="POST" class='form' enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Create New Client</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                                <!-- Client Name -->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <input type="text" name="first_name" class="form-control" value="" placeholder="First Name" required>
                                        </div>        
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <input type="text" name="last_name" class="form-control" value="" placeholder="Last Name" required>
                                        </div>        
                                    </div>
                                </div>
                                
                                <!-- E-Mail -->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <input type="email" name="email" class="form-control" value="" placeholder="E-Mail" required>
                                        </div>        
                                    </div>
                                </div>
                                
                                <!-- Password -->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <input type="password" name="password" class="form-control" value="" placeholder="Password" required>
                                            <input type="checkbox" name="show_client_password" style="color:lightgrey;"> Show Password
                                        </div>        
                                    </div>
                                </div>
                                
                                <!-- Client Description-->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <textarea name="description" id="description" class="form-control" cols="30" rows="5" placeholder="Description"></textarea>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Role -->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <select class="form-control" name="client_role">
                                                <?php if($roles->count() != 0): ?>
                                                    <option value="" disabled selected hidden> -- Select Role -- </option>
                                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->role); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                <?php else: ?>
                                                    <option value="" disabled selected hidden> -- No Role Found! -- </option>
                                                <?php endif; ?>
                                                
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Profile -->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <label for="">Client Profile</label>
                                            <input type="file" name="client_profile" class="form-control">
                                        </div>
                                    </div>
                                </div>
                          </div>
                          
                          <div class="modal-footer">
                            <!--<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
                            <button type="submit" class="btn btn-primary btn-sm">Create</button>
                          </div>
                          
                      </form>
                    </div>
                  </div>
                </div>
          </div>
        </div>
        
        <br><br>
        
        <table id="clients_datatable" class="display">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Client</th>
                    <th scope="col">Description</th>
                   <!--<th scope="col">Project Deadline</th> -->
                    <th scope="col" style="width:130px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if($projects->count() == 0): ?>
            <tr >
                <td colspan="6">NO CLIENT FOUND!</td>
            </tr>
                
            <?php else: ?>
                <?php $no =1; ?>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($no++); ?></th>
                    <td><?php echo e($client->name); ?></td>
                    <td><?php echo e($client->description); ?></td>
                    <td>
                        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($per == 13): ?>
                                <!-- View Project -->
                                <a class="me-3 view_project_trigger" data="<?php echo e($client->id); ?>"><i class="far fa-eye" ></i></a>    
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <!-- Edit modal -->
                        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($per == 14): ?>
                                <a class="me-3 edit_project_trigger" data="<?php echo e($client->id); ?>" data-bs-toggle="modal"><i class="far fa-edit open" ></i></a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <!-- Delete Client -->
                        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($per == 15): ?>
                                <a class="delete-client-trigger" data='<?php echo e($client->id); ?>'><i class="far fa-trash-alt"  style="color:red;"></i></a> 
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
      </section>
</main>


<!-- View project modal -->
<div class="modal" tabindex="-1" id="view_project_modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          
        <div>
            <b>Description: </b>
            <p id="view_descritpion"></p>
        </div>
        
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Edit project modal -->
<div class="modal" tabindex="-1" id="edit_project_modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form action="<?php echo e(route('update-project')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal-body">

          <!-- First Name -->
          <div class="form-group mb-3">
            <input type="text" placeholder="First Name" id="edit_project_first_name" name="first_name" value="" class="form-control">
          </div>
          
          <!-- Last Name -->
          <div class="form-group mb-3">
            <input type="text" placeholder="Last Name" id="edit_project_last_name" name="last_name" value="" class="form-control">
          </div>

          <!-- Description -->
          <div class="form-group mb-3">
            <textarea name="description" cols="30" rows="10" class="form-control" value="" id="edit_project_description"></textarea>
          </div>

          <!-- Project id -->
          <input type="hidden" name="edit_project_id" id="edit_project_id" value="">
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-primary" value="Update">
        </div>
      </form>
    </div>
  </div>
</div>
<!-- edit modal ends -->


<!-- Delete client confirm modal -->
<div class="modal" tabindex="-1" id="confirm-delete-client-modal">
  <div class="modal-dialog">
    <div class="modal-content">
        <form action="<?php echo e(route('delete-project')); ?>" method='POST' class='form'>
            <?php echo csrf_field(); ?>
          <div class="modal-body">
            <p id='message_in_confirm_delete_client_modal'></p>
            <input type='hidden' name='id' id='id_in_confirm_delete_client_modal' value=''>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-danger">Delete</button>
          </div>
      </form>
    </div>
  </div>
</div>

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gbsprojects/public_html/taskmanagement/resources/views/projects.blade.php ENDPATH**/ ?>