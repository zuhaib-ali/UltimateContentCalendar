<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="container mt-5 pt-5">
        <div class="row">
            <div class="col-12">
                <center><h2>Comment</h2></center>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div id="comment-form-container" style="margin:0px 100px; padding:20px; border:1px solid lightgrey; box-shadow: 0px 0px 1px lightgrey; background-color:ghostwhite;">
                    <form action="<?php echo e(url('create_comment')); ?>" method="POST" class="form">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <!-- Plateform -->
                            <div class="form-group col-lg-6">
                                <label for="post_link">Platform</label>
                                <select name="platform" id="" class="form-control">
                                    <option disabled selected value> -- select a platform -- </option>
                                    <option value="youtube">Youtube</option>
                                    <option value="facebook">Facebook</option>
                                    <option value="instagram">Instagram</option>
                                    <option value="twitter">Twitter</option>
                                </select>
                            </div>

                            <!-- Post link -->
                            <div class="form-gourp col-lg-6">
                                <label for="post_link">Commet Type</label>
                                <select name="comment_type" id="" class="form-control">
                                    <option disabled selected value> -- select a comment type -- </option>
                                    <option value="comment">Comment</option>
                                    <option value="review">Review</option>
                                    <option value="direct quote">Dirrect Quote</option>
                                </select>
                            </div>
                        </div>


                        <!-- Post link -->
                        <div class="form-group">
                            <label for="post_link">Post Link</label>
                            <input type="text" name="url" id="post_link" class="form-control">
                        </div>
                        

                        <div class="row">
                            <!-- Comment -->
                            <div class="form-group col-lg-6">
                                <label for="comment">Comment</label>
                                <textarea name="actual_comment" id="comment" cols="10" rows="5" class="form-control"></textarea>    
                            </div>

                            <!-- Feedback -->
                            <div class="form-group col-lg-6">
                                <label for="feedback">Feedback</label>
                                <textarea name="feedback" id="feedback" cols="10" rows="5" class="form-control"></textarea>
                            </div>
                        </div>
                            
                        <!-- Submit button -->
                        <div class="form-group">
                            <input type="submit" class="btn btn-success" value="SEND">
                        </div>

                    </form>
                    <!-- end comment form -->
                </div>

            </div>
        </div>

    </main>
<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gbsprojects/public_html/taskmanagement/resources/views/commentingSystem/comments.blade.php ENDPATH**/ ?>