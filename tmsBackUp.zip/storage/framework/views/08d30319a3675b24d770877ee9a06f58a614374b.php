<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Container Main start-->
<div class="main-container">
    <div class="row">
        <div class="col-12">
            <center><h2>Settings</h2></center>
        </div>
    </div>

	<div class="row">
		<div class="col-2">
			<form class="form" action="<?php echo e(route('set-colors')); ?>" method="POST">
				<?php echo csrf_field(); ?>
					
					<!-- Pneding -->
					<div class="form-group">
						<div class="d-flex justify-content-between" id="pending_column">
							<span> Pending:  </span>
							<div id="pending" class="colorSelector">
								<div ></div>
							</div>
						</div>
						<input type="hidden" name="pending_color" id="pending_color" value="<?php if($settings_colors->count() != 0): ?> <?php echo e($settings_colors->find(1)->status_color); ?> <?php else: ?> #FFBF00 <?php endif; ?>">
					</div>

					<!-- In process -->
					<div class="form-group">
						<div class="d-flex justify-content-between" id="in_progress_column">
							<span > In Progress: </span>
							<div id="in_progress" class="colorSelector">
								<div class="in_progress-color"></div>
							</div>
						</div>

						<input type="hidden" name="in_progress_color" id="in_progress_color" value="<?php if($settings_colors->count() != 0): ?> <?php echo e($settings_colors->find(2)->status_color); ?> <?php else: ?> #4682B4 <?php endif; ?>">
					</div>

					<!-- Approved -->
					<div class="form-group">
						<div class="d-flex justify-content-between" id="approve_column">
							<span > Approve: </span>
							<div id="approve" class="colorSelector">
								<div class="approve-color"></div>
							</div>
						</div>

						<input type="hidden" name="approve_color" id="approve_color" value="<?php if($settings_colors->count() != 0): ?> <?php echo e($settings_colors->find(3)->status_color); ?> <?php else: ?> #01796F <?php endif; ?>">
					</div>

					<!-- Complete -->
					<div class="form-group">
						<div class="d-flex justify-content-between" id="complete_column">
							<span> Complete: </span>
							<div id="complete" class="colorSelector">
								<div class="complete-color"></div>
							</div>
						</div>

						<input type="hidden" name="complete_color" id="complete_color" value="<?php if($settings_colors->count() != 0): ?> <?php echo e($settings_colors->find(4)->status_color); ?> <?php else: ?> #4CBB17 <?php endif; ?>">
					</div>

					<!-- Reject -->
					<div class="form-group">
						<div class="d-flex justify-content-between" id="reject_column">
							<span> Revine: </span>
							<div id="reject" class="colorSelector">
								<div class="reject-color"></div>
							</div>
						</div>

						<input type="hidden" name="reject_color" id="reject_color" value="<?php if($settings_colors->count() != 0): ?> <?php echo e($settings_colors->find(5)->status_color); ?> <?php else: ?> #C21807 <?php endif; ?>">
					</div>
				<br>
				<hr>
				<div class="form-group">
					<input type="submit" value="Set Colors" class="btn btn-secondary form-control">
				</div>
			</form>
		</div>
	</div>
</div>

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>

	
	// Pending
	$('#pending').ColorPicker({
			color: '#FFBF00',
			onShow: function (colpkr) {
				$(colpkr).fadeIn(500);
				return false;
			},
			onHide: function (colpkr) {
				$(colpkr).fadeOut(500);
				return false;
			},
			onChange: function (hsb, hex, rgb) {
				$("#pending_column").css({"border-color":"#"+hex, "border-bottom": "5px solid #"+hex});
				$("#pending_column #pending div").css("background-color", "#"+hex);
				$("#pending_column span").css("color", "#"+hex);
				$("#pending_color").val("#"+hex);
			}
		});

		// In Process
		$('#in_progress').ColorPicker({
			color: '#4682B4',
			onShow: function (colpkr) {
				$(colpkr).fadeIn(500);
				return false;
			},
			onHide: function (colpkr) {
				$(colpkr).fadeOut(500);
				return false;
			},
			onChange: function (hsb, hex, rgb) {
				$("#in_progress_column").css({"color":"#"+hex, "border-bottom": "5px solid #"+hex});
				$('#in_progress_column #in_progress div').css('backgroundColor', '#' + hex);
				$("#in_progress_column span").css({"color":"#"+hex });
				$("#in_progress_color").val("#"+hex);
			}
		});

		
		// Approve
		$('#approve').ColorPicker({
			color: '#01796F',
			onShow: function (colpkr) {
				$(colpkr).fadeIn(500);
				return false;
			},
			onHide: function (colpkr) {
				$(colpkr).fadeOut(500);
				return false;
			},
			onChange: function (hsb, hex, rgb) {
				$("#approve_column").css({"border-color":"#"+hex, "border-bottom": "5px solid #"+hex});
				$("#approve_column #approve div").css('backgroundColor', '#' + hex);
				$("#approve_column span").css({"color":"#"+hex});
				$("#approve_color").val("#"+hex);
			}
		});

		// Compelete
		$('#complete').ColorPicker({
			color: '#4CBB17',
			onShow: function (colpkr) {
				$(colpkr).fadeIn(500);
				return false;
			},
			onHide: function (colpkr) {
				$(colpkr).fadeOut(500);
				return false;
			},
			onChange: function (hsb, hex, rgb) {
				$("#complete_column").css({"border-color":"#"+hex, "border-bottom": "5px solid #"+hex});
				$('#complete_column #complete div').css('backgroundColor', '#' + hex);
				$("#complete_column span").css({"color":"#"+hex});
				$("#complete_color").val("#"+hex);
			}
		});

		// Reject
		$('#reject').ColorPicker({
			color: '#C21807',
			onShow: function (colpkr) {
				$(colpkr).fadeIn(500);
				return false;
			},
			onHide: function (colpkr) {
				$(colpkr).fadeOut(500);
				return false;
			},
			onChange: function (hsb, hex, rgb) {
				$("#reject_column").css({"border-color": "#"+hex, "border-bottom": "5px solid #"+hex});
				$('#reject_column #reject div').css('backgroundColor', '#' + hex);
				$("#reject_column span").css("color", "#"+hex);
				$("#reject_color").val("#"+hex);
			}
		});
</script>
<?php /**PATH C:\xampp\htdocs\taskly\resources\views/settings.blade.php ENDPATH**/ ?>