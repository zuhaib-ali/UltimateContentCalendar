<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="container mt-5 pt-5">
  <div class="row">
    <div class="col-12">
      <center>
        <h2>Dashboard</h2>
      </center>
    </div>
  </div>

  <div class="row">
    <div class="col-12 boxes">
      <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($per == 1): ?>
          <div class="card bg-danger text-white">
            <div class="card-body">
              <center>
                <h2>Add Role and Permissions</h2>
              </center>
            </div>
            <div class="card-footer">
              <center><a href="<?php echo e(route('roles')); ?>">View</a></center>
            </div>
          </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($per == 1): ?>
            <div class="card bg-success text-white">
              <div class="card-body">
                <center>
                  <h2>Roles</h2>
                  <h3><?php echo e($roles->count()); ?></h3>
                </center>
              </div>
              <div class="card-footer">
                <center><a href="<?php echo e(route('manage_roles')); ?>">View</a></center>
              </div>
            </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($per == 2): ?>
            <div class="card bg-primary text-white">
              <div class="card-body">
                <center>
                  <h2>Users</h2>
                  <h3><?php echo e($users->count()); ?></h3>
                </center>
              </div>
              <div class="card-footer">
                <center><a href="<?php echo e(route('users')); ?>">View</a></center>
              </div>
            </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      

        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($per == 3): ?>
            <div class="card bg-warning text-white">
              <div class="card-body">
                <center>
                  <h2>Projects</h2>
                  <h3><?php echo e($projects->count()); ?></h3>
                </center>
              </div>
              <div class="card-footer">
                <center><a href="<?php echo e(route('projects')); ?>">View</a></center>
              </div>
            </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($per == 4): ?>
            <div class="card bg-info text-white">
              <div class="card-body">
                <center>
                  <h2>Tasks</h2>
                  <?php if(Session::get("user")->role_id == 1): ?>
                    <h3><?php echo e($tasks->count()); ?></h3>
                  <?php else: ?>
                    <h3><?php echo e($tasks->where("user_id", Session::get("user")->id)->count()); ?></h3>
                  <?php endif; ?>
                </center>
              </div>
              <div class="card-footer">
                <center><a href="<?php echo e(route('tasks')); ?>">View</a></center>
              </div>
            </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($per == 6): ?>
          <div class="card bg-danger text-white">
            <div class="card-body">
              <center>
                <h2>Calendar</h2>
                
              </center>
            </div>
            <div class="card-footer">
              <center><a href="<?php echo e(route('task-calendar-wise')); ?>">View</a></center>
            </div>
          </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($per == 5): ?>
          <div class="card bg-secondary text-white">
            <div class="card-body">
              <center>
                <h2>Settings</h2>
                
              </center>
            </div>
            <div class="card-footer">
              <center><a href="<?php echo e(route('settings')); ?>">View</a></center>
            </div>
          </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </div>
</main>

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskly\resources\views/index.blade.php ENDPATH**/ ?>