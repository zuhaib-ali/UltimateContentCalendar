<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="container mt-5 pt-5">
    <!-- Manage role starts -->
    <section id="second-container">
        <div class="row mt-4">
          <div>
            <h3 class="text-center">Manage Role</h3>
          </div>
          <div class="m-auto mt-4">
                <table id="roles_datatable" class="display">
                    <thead>
                        <tr>
                            <th scope="col" width="10%">#</th>
                            <th scope="col" width="30%">Role name</th>
                            <th scope="col" width="30%">Description</th>
                            <th scope="col" width="20%">Permissions</th>
                            <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($per == 24): ?>
                                    <th scope="col" width="5%">Edit</th>        
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($per == 25): ?>
                                    <th scope="col" width="5%">Delete</th>        
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($roles->count() == 0): ?>
                  <tr><td colspan="6">NO ROLE FOUND!</td></tr>
                <?php else: ?>
                  <?php $SNo = 1;?>
                  <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                      <td><?php echo e($SNo++); ?></td>
                      <td><?php echo e($role->role); ?></td>
                      <td><?php echo e($role->description); ?></td>
                      
                      <td>
                        <?php if($role->permissions_id == 'NA'): ?>
                          NA
                        <?php else: ?>
                          <ol>
                            <?php $__currentLoopData = $role->permissions_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($permissions->find($permission)->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ol>
                        <?php endif; ?>
                      </td>

                      
                          
                        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($per == 24): ?>
                            <td>
                                <!-- Edit modal -->
                                <i class="far fa-edit open" data-bs-toggle="modal" data-bs-target="#edit_modal_<?php echo e($role->id); ?>"></i>
                                
                                  <div class="modal" tabindex="-1" id="edit_modal_<?php echo e($role->id); ?>">
                                    <div class="modal-dialog">
                                      <div class="modal-content">
        
                                        <div class="modal-header">
                                          <h5 class="modal-title">Edit <?php echo e($role->role); ?></h5>
                                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        
                                        <form action="<?php echo e(route('update_role')); ?>" method="POST">
                                          <?php echo csrf_field(); ?>
                                          <div class="modal-body">
                                            <div class="row">
                                              <div class="col-6">
                                                <p>Role Name</p>
                  
                                              </div>
                                              <div class="col-6">
                                                <div class="mb-3">
                                                  <input type="text" name="role" class="form-control" value="<?php echo e($role->role); ?>" id="exampleFormControlInput1" placeholder="Role Name">
                                                </div>
                  
                                              </div>
                                            </div>
                                            <div class="row">
                                              <div class="col-6">
                                                <p>Discription</p>
                  
                                              </div>
                                              <div class="col-6">
                                                <div class="mb-3">
                                                  <textarea class="form-control" name="description" value="" id="exampleFormControlTextarea1" rows="3"><?php echo e($role->description); ?></textarea>
                                                </div>
                  
                                              </div>
                                            </div>
                                            <div class="row">
                                              <div class="col-12">
                                                <table class="table">
                                                  <thead>
                                                    <tr>
                                                      <th scope="col" width="20%">#</th>
                                                      <th scope="col" width="60%">Permission</th>
                                                      <th scope="col" width="20%">Action</th>
                                                    </tr>
                                                  </thead>
                                                  <tbody>
                                                    <?php if($permissions->count() != 0): ?>
                                                      <?php $no =1; ?>
                                                      <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                                                      <tr>
                                                        <th scope="row"><?php echo e($no++); ?></th>
                                                        <td><?php echo e($permission->name); ?></td>
                                                        <td>
                                                          <div class="form-check">
                                                            
                                                            <input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" <?php if($role->permissions_id != "NA"): ?> <?php $__currentLoopData = $role->permissions_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($per == $permission->id): ?> checked <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>>
                                                            
                                                          </div>
                                                        </td>
                                                      </tr>
        
                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                  </tbody>
        
                                                </table>
                                                <!-- tables ends -->
                                              </div>
                                            </div>
                                          </div>
                                          <!-- Modal body ends -->
        
                                          <!-- Role id -->
                                          <input type="hidden" name="id" value="<?php echo e($role->id); ?>">
        
                                          <!-- modal footer starts -->
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <input type="submit" class="btn btn-primary" value="Update">
                                            <!-- <button type="submit" class="btn btn-primary">Save changes</button> -->
                                          </div>
                                        </form>
                                      </div>
                                    </div>
                                  </div>    
                                </td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      
                        
                        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($per == 25): ?>
                                <td>
                                    <!-- Delete Role -->
                                    <a class="delete-role-trigger" data='<?php echo e($role->id); ?>'><i class="far fa-trash-alt"  style="color:red;"></i></a>
                                </td> 
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                    </tbody>
                </table>              
              
          </div>

        </div>
      </section>
</main>

<div class="modal" tabindex="-1" id="confirm-delete-role-modal">
  <div class="modal-dialog">
    <div class="modal-content">
        <form action="<?php echo e(route('delete_role')); ?>" method='POST' class='form'>
            <?php echo csrf_field(); ?>
          <div class="modal-body">
            <p id='message_in_confirm_delete_role_modal'></p>
            <input type='hidden' name='id' id='id_in_confirm_delete_role_modal' value=''>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-danger">Delete</button>
          </div>
      </form>
    </div>
  </div>
</div>

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gbsprojects/public_html/taskmanagement/resources/views/roles/manage_roles.blade.php ENDPATH**/ ?>