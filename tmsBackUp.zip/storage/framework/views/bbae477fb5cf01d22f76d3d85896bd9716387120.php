<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="container mt-5 pt-5">
<section id="second-container3">
        <div class="main-container-two">
            <div class="welcome-note-two">
              <h4>Projects (<?php echo e($tasks->count()); ?>)</h4>
            </div>
          <div>

          <!-- ADD task modal -->
          <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($per == 8): ?>
              <button class="btn btn-success" data-bs-toggle="modal"  data-bs-target="#add_task" type="button">Create Project</button>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          <div class="modal" tabindex="-1" id="add_task">
              <div class="modal-dialog">
                <div class="modal-content">

                  <div class="modal-header">
                    <h5 class="modal-title">Create Project</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  
                  <form action="<?php echo e(route('add-task')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <!-- Clients -->
                        <div class="row">
                            <div class="">
                                <div class="mb-3">
                                    
                                    <label for="roles">Clients</label>
                                    <select name="project_id" id="roles" class="form-control" required>
                                    <?php if($projects->count() != 0): ?>
                                        <option disabled selected value> -- select a client -- </option>
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="" style="font-style:italic;">Clients Not Found</option>
                                    <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        
                        
                        <div class="row">
                            <div class="">
                                <div class="mb-3">
                                    <label for="first name">Project Name</label>
                                    <input type="text" name="task_name" class="form-control" value="" id="first_name" placeholder="Project Name" required>
                                </div>        
                            </div>
                        </div>
                        
                        <!-- Description -->
                        <div class="row">
                            <div class="">
                                <div class="mb-3">
                                    <label for="description">Description</label>
                                    <textarea name="description" class="form-control" cols="30" rows="3" placeholder="Editor's Description"></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Caption -->
                        <div class="row">
                            <div class="">
                                <div class="mb-3">
                                    <label for="caption">Post Caption</label>
                                    <textarea name="caption" class="form-control" cols="30" rows="3" placeholder="Post Caption"></textarea>
                                </div>
                            </div>
                        </div>


                        <!-- Caption status -->
                        <div class="row">
                            <div class="">
                                <div class="mb-3">
                                    <label for="caption_status name">Caption</label>
                                    <select class="form-control" name="caption_status">
                                        <option disabled selected hidden>-- SELECT CAPTION STATUS --</option>
                                        <option value="12">Caption Waiting For Approval</option>
                                        <option value="13">Revise Caption</option>
                                        <option value="14">Caption Approved</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Project assigned to User -->
                        <div class="row assigned">
                            <div class="">
                                <div class="mb-3">
                                    
                                    <label for="roles">Assigned To</label>
                                    
                                    <select name="user_id" id="roles" class="form-control users" required>
                                    <?php if($users->count() != 0): ?>
                                        <option disabled selected value> -- ASSIGNED TO -- </option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($project->id); ?>"><?php echo e($project->first_name); ?> <?php echo e($project->last_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="" style="font-style:italic;">Assinged To Not Found</option>
                                    <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Post Date -->
                        <div class="row">
                            <div class="">
                                <div class="mb-3">
                                    
                                    <label for="deadline">Post Date</label>
                                    <input type="date" name="deadline" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        
                        
                        <!-- Post Date -->
                        <div class="row">
                            <div class="">
                                <div class="mb-3">
                                    
                                    <label for="due_to_date">Due to Date</label>
                                    <input type="date" name="due_to_date" class="form-control" required>
                                </div>
                            </div>
                        </div>

                        <!-- Files -->
                        <div class="row">
                            <div class="">
                                <div class="mb-3">
                                    
                                    <label for="upload files">Upload files</label>
                                    <input type="file" name="task_files[]" class="form-control" multiple>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Auto assign -->
                        <center>
                            <div class="row">
                                <div class="">
                                    <div class="mb-3">
                                        
                                        <label for="auto assign">AUTO ASSIGN</label>
                                        <input type="checkbox" value="1" name="auto_assign" class="auto_assign"/>
                                    </div>
                                </div>
                            </div>
                        </center>
                    </div>

                    <!-- modal footer starts -->
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <input type="submit" class="btn btn-primary" value="Add">
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <!-- add user modal ends -->
          </div>
        </div>
        
        <br><br>
        
        <table id="prjects_datatable" class="display">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Project</th>
                    <th scope="col">Client</th>
                    <!--<th scope="col">Assigned to</th>-->
                    <th scope="col">Status</th>
                    <?php if(session()->get('user')->role_id == 1): ?>
                        <th scope="col">Post Date</th>
                    <?php else: ?>
                        <th scope="col">Due Date</th>
                    <?php endif; ?>
                    <th scope="col" style="width:130px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if($tasks->count() == 0): ?>
              <tr >
                  <td colspan="7">NO TASK FOUND!</td>
              </tr>
                
                
                
                
                
            <?php else: ?>
            <?php $no =1; ?>
              <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($no++); ?></th>
                  <td><?php echo e($task->name); ?> - <i><?php echo e($task->first_name); ?> <?php echo e($task->last_name); ?></i></td>
                  <td><?php echo e($task->project_name); ?></td>
                  <!--<td><?php echo e($task->first_name); ?> <?php echo e($task->last_name); ?></td>-->
                  <td><span style="color:<?php echo e($task->status_color); ?>; font-weight:bold; text-transform:uppercase"><?php echo e($task->status_name); ?></span></td>
                    <?php if(session()->get('user')->role_id == 1): ?>
                        <td><?php echo e($task->deadline != null ? Carbon\Carbon::create($task->deadline)->format('d M, y') : ''); ?></td>
                        <?php else: ?>
                        <td><?php echo e($task->due_to_date != null ? Carbon\Carbon::create($task->due_to_date)->format('d M, y') : ''); ?></td>
                    <?php endif; ?>
                    
                  <td>
                      <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($per == 16): ?>
                          <!-- View Modal -->
                          <a href="#" class="me-2  view_task_trigger" data="<?php echo e($task->id); ?>"><i class="far fa-eye" data-viewId="<?php echo e($task->id); ?>" data-bs-toggle="modal" data-bs-target="#view_modal_<?php echo e($task->id); ?>"></i></a>
                          <div class="modal" tabindex="-1" id="view_modal_<?php echo e($task->id); ?>">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                  
                                  <!-- Modal Header -->
                                  <div class="modal-header">
                                    <h5 class="modal-title">
                                      <span>View: <?php echo e($task->name); ?></span>
                                        <?php if($task->status == 1): ?>
                                          <span class="view_task_label" style="color:var( --pending-color);"><?php echo e($colors->find(1)->status_name); ?></span>
                                        <?php elseif($task->status == 2): ?>
                                          <span class="view_task_label" style="color:var( --in_progress-color);"><?php echo e($colors->find(2)->status_name); ?></span>
    
                                        <?php elseif($task->status == 3): ?>
                                          
                                          <?php if($task->revine_date == ""): ?>
                                            <span class="view_task_label" style="color:var( --approve-color);"><?php echo e($colors->find(3)->status_name); ?></span>
                                          <?php else: ?>
                                            <span class="view_task_label" style="color:var( --revined-color);"><?php echo e($colors->find(5)->status_name); ?></span>
                                          <?php endif; ?>
    
                                        <?php elseif($task->status == 4): ?>
                                          <span class="view_task_label" style="color:var( --complete-color);"><?php echo e($colors->find(4)->status_name); ?></span>
                                        <?php elseif($task->status == 5): ?>
                                          <span class="view_task_label" style="color:var( --revined-color);"><?php echo e($colors->find(5)->status_name); ?></span>
                                        <?php endif; ?>
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                  </div>
                                             
                                  <!-- Modal Body -->
                                  <div class="modal-body">
                                    <p class="d-flex justify-content-between">
                                      <span><b>Post Date:</b></span> 
                                      <span><?php echo e(date('d-m-Y', strtotime($task->deadline))); ?></span>
                                    </p>
                                    <p>
                                      <span><b>Description:</b></span><br>
                                      &nbsp;&nbsp;<span><?php echo e($task->description); ?></span>
                                    </p>
    
                                    <?php if( $task_files->count() != 0): ?>
                                    <b>Attachments:</b>
                                    <div style="display:block">
                                      <?php $__currentLoopData = $task_files->where("task_id", $task->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task_file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                                        <div style="border:1px solid lightgrey; padding:10px; margin:10px; display:flex; justify-content:space-between">
                                          <!-- Attachment -->
                                          <?php echo e($task_file->file_name); ?>

                                          <!-- donwload button -->
                                          
                                          <a href="https://taskmanagement.gbsprojects.xyz/public/task_files/<?php echo e($task_file->file_name); ?>" class="btn btn-sm btn-success">Download</a>
                                        </div>
    
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php endif; ?>
    
                                    <!-- Subtasks -->
                                     <?php if($sub_tasks->count() != 0): ?>
                                      <?php $sub_task_no = 1;?>
                                      <?php $__currentLoopData = $sub_tasks->where("main_task", $task->id)->where("revined", false); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="sub-task-container" style="border:1px solid lightgrey; padding:15px; margin:10px 0px;">
                                          <div class="sub-task">
                                            <div>
                                              <?php if($task->status == 3): ?>
                                                <div><p class="view_task_label" style="color:<?php echo e($colors->find(3)->status_color); ?>; float:right;"><?php echo e($colors->find(3)->status_name); ?></p></div>
                                              <?php else: ?>
                                                <div><p class="view_task_label" style="color:<?php echo e($colors->find($sub_task->status)->status_color); ?>; float:right;"><?php echo e($colors->find($sub_task->status)->status_name); ?></p></div>
                                              <?php endif; ?>
                                              <br>
                                              <p class="d-flex justify-content-between w-100"><b>Subject:</b> <span><?php echo e($sub_task->subject); ?> </span></p>
                                              <p>
                                                <b>Description:</b>
                                                <br> 
                                                &nbsp;&nbsp;<span><?php echo e($sub_task->description); ?> </span></p>
                                            </div>
                                          </div>
    
                                          <b>Attachments</b>
    
                                          <!-- attachements -->
    
                                          <?php if( $task_files->count() != 0): ?>
                                            <div style="display:block;">
                                              <?php $__currentLoopData = $task_files->where("sub_task_id", $sub_task->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task_file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  
                                                <div style="border:1px solid lightgrey; padding:10px; margin:10px; display:flex; justify-content:space-between">
                                                  <!-- Attachment -->
                                                  <?php echo e($task_file->file_name); ?>

                                                  <!-- donwload button -->
                                                  <a href="https://taskmanagement.gbsprojects.xyz/public/task_files/<?php echo e($task_file->file_name); ?>" class="btn btn-sm btn-success">Download</a>
                                                </div>
    
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                          <?php endif; ?>
    
                                        <div class="d-flex justify-content-end">
                                            <!-- Subtask status buttons -->
                                              <?php if($sub_task->color_id == 1 && Session::get("user")->role_id != 1): ?>
                                                <a href="<?php echo e(route('update-subtask-status', ['status_id' => 2, 'task_id' => $sub_task->id])); ?>" class="btn btn-light" style="background-color:<?php if($colors->count() != 0): ?> <?php echo e($colors->find(2)->status_color); ?>; <?php else: ?> lightblue <?php endif; ?> color:white;">In Progress</a>
                                              <?php elseif($sub_task->color_id == 2 && Session::get("user")->role_id != 1): ?>
                                                <a href="<?php echo e(route('update-subtask-status', ['status_id' => 4, 'task_id' => $sub_task->id])); ?>" class="btn btn-light" style="background-color:<?php if($colors->count() != 0): ?> <?php echo e($colors->find(4)->status_color); ?>; <?php else: ?> lightblue <?php endif; ?> color:white;">Complete</a>
                                              <?php elseif($sub_task->color_id == 5): ?>
                                                <p class="btn btn-light" style="background-color:<?php if($colors->count() != 0): ?> <?php echo e($colors->find(5)->status_color); ?>; <?php else: ?> 'lightblue' <?php endif; ?> color:white;">Task rejectd, wait for admin to if he pedning the rejected task again.</p>
                                              <?php elseif($sub_task->color_id == 4 && Session::get("user")->role_id != 1 && $task->color_id == 5): ?>
                                                <p style="color: <?php echo e($colors->find(4)->status_color); ?>">Waiting for approval, on task rejection status will be pending again.</p>
                                              <?php elseif($sub_task->color_id == 3): ?>
                                                <p style="background-color:<?php if($colors->count() != 0): ?> <?php echo e($colors->find(2)->status_color); ?>; <?php else: ?> 'lightblue' <?php endif; ?> color:white; width:100%; text-align:center; padding:10px">TASK APPROVED</p>
                                              <?php endif; ?>
                                        </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    <?php endif; ?>
                                  </div>
                                  
                                  <!-- modal footer starts -->
                                  <div class="modal-footer">
                                      
                                    <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($per == 22): ?>
                                            <?php if(Session::get("user")->role_id == 1): ?>
                                              <!-- On completion of task, show reject and approve button -->
                                              <?php if($sub_tasks->where("main_task", $task->id)->where("revined", false)->pluck("status")->first() == 4 || $task->status == 4): ?>
                                                <?php if($task->color_id == 4): ?>
                                                  <a type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-dismiss="modal" data-bs-target="#revine_task_modal_<?php echo e($task->id); ?>" style="background-color:<?php if($colors->count() != 0): ?> <?php echo e($colors->find(5)->status_color); ?>; <?php else: ?> 'lightblue' <?php endif; ?> color:white;">Revine</a>
                                                  <a href="<?php echo e(route('update-status', ['status_id' => 3, 'task_id' => $task->id])); ?>" class="btn btn-light" style="background-color:<?php if($colors->count() != 0): ?> <?php echo e($colors->find(3)->status_color); ?>; <?php else: ?> 'lightblue' <?php endif; ?> color:white;">Approve</a>
                                                <?php elseif($task->color_id == 5): ?>
                                                  <a type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-dismiss="modal" data-bs-target="#revine_task_modal_<?php echo e($task->id); ?>" style="background-color:<?php if($colors->count() != 0): ?> <?php echo e($colors->find(5)->status_color); ?>; <?php else: ?> 'lightblue' <?php endif; ?> color:white;">Revine</a>
                                                  <a href="<?php echo e(route('update-status', ['status_id' => 3, 'task_id' => $task->id])); ?>" class="btn btn-light" style="background-color:<?php if($colors->count() != 0): ?> <?php echo e($colors->find(3)->status_color); ?>; <?php else: ?> 'lightblue' <?php endif; ?> color:white;">Approve</a>
                                                <?php endif; ?>
                                              <?php endif; ?>
            
                                            <?php elseif(Session::get("user")->client_id == null): ?>
                                              <?php if($task->color_id == 1): ?>
                                                <a href="<?php echo e(route('update-status', ['status_id' => 2, 'task_id' => $task->id])); ?>" class="btn btn-light" style="background-color:<?php if($colors->count() != 0): ?> <?php echo e($colors->find(2)->status_color); ?>; <?php else: ?> 'lightblue' <?php endif; ?> color:white;">In Progress</a>
                                              <?php elseif($task->color_id == 2): ?>
                                                <a href="<?php echo e(route('update-status', ['status_id' => 4, 'task_id' => $task->id])); ?>" class="btn btn-light" style="background-color:<?php if($colors->count() != 0): ?> <?php echo e($colors->find(4)->status_color); ?>; <?php else: ?> 'lightblue' <?php endif; ?> color:white;">Complete</a>
                                              <?php elseif($task->color_id == 4): ?>
                                                <p style="color: <?php echo e($colors->find(4)->status_color); ?>">Waiting for approval, on task rejection status will be pending again.</p>
                                              <?php elseif($task->color_id == 3): ?>
                                                <p style="background-color:<?php if($colors->count() != 0): ?> <?php echo e($colors->find(2)->status_color); ?>; <?php else: ?> 'lightblue' <?php endif; ?> color:white; width:100%; text-align:center; padding:10px">TASK APPROVED</p>
                                              <?php endif; ?>
            
                                            <?php endif; ?>      
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                  </div>
                                </form>
                              </div>
                            </div>
                          </div>
                         </div>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      
                      <!-- Edit Task -->
                      <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($per == 17): ?>
                          <!-- Edit modal -->
                            <?php if($task->status == 1): ?>
                              <a href="#" class="me-2"><i class="far fa-edit open" data-bs-toggle="modal" data-bs-target="#edit_modal_<?php echo e($task->id); ?>" style="color:green;"></i></a>
                            <?php endif; ?>
                            <div class="modal" tabindex="-1" id="edit_modal_<?php echo e($task->id); ?>">
                              <div class="modal-dialog">
                                <div class="modal-content">
    
                                  <div class="modal-header">
                                    <h5 class="modal-title">Edit - <?php echo e($task->name); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                  </div>
    
                                  <form action="<?php echo e(route('update-task')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                        
                                        <!-- Task name -->
                                        <div class="row">
                                            <div class="">
                                                <div class="mb-3">
                                                    <input type="text" name="task_name" class="form-control" value="<?php echo e($task->name); ?>" id="first_name" placeholder="Task Name" required>
                                                </div>        
                                            </div>
                                        </div>
                                        
                                        <!-- Projects -->
                                        <div class="row">
                                            <div class="">
                                                <div class="mb-3">
                                                    <label for="roles">Clients</label>
                                                    <select name="project_id" id="project_id" class="form-control" required>
                                                    <?php if($projects->count() != 0): ?>
                                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($project->id); ?>" <?php if($task->project_id == $project->id): ?> selected <?php endif; ?>><?php echo e($project->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <option value="" style="font-style:italic;">Projects Not Found</option>
                                                    <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Description -->
                                        <div class="row">
                                            <div class="">
                                                <div class="mb-3">
                                                    <textarea name="description" id="description" class="form-control" cols="30" rows="5" placeholder="Editor's Description"><?php echo e($task->description); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
    
                                        <!-- Caption -->
                                        <div class="row">
                                            <div class="">
                                                <div class="mb-3">
                                                    <textarea name="caption" id="caption" class="form-control" cols="30" rows="5" placeholder="Post Caption"><?php echo e($task->caption); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Caption status -->
                                        <div class="row">
                                            <div class="">
                                                <div class="mb-3">
                                                    <select class="form-control" name="caption_status">
                                                        <option disabled selected hidden>-- SELECT CAPTION STATUS --</option>
                                                        <option value="12" <?php if($task->caption_status == 12): ?> active <?php endif; ?>>Caption Waiting For Approval</option>
                                                        <option value="13" <?php if($task->caption_status == 13): ?> active <?php endif; ?>>Revise Caption</option>
                                                        <option value="14" <?php if($task->caption_status == 14): ?> active <?php endif; ?>>Caption Approved</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
    
                                        <!-- Assigend to -->
                                        <div class="row">
                                            <div class="">
                                                <div class="mb-3">
                                                    <label for="roles">Assigned To</label>
                                                    <select name="user_id" id="user_id" class="form-control" required>
                                                    <?php if($users->count() != 0): ?>
                                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                          <option value="<?php echo e($user->id); ?>" <?php if($task->user_id == $user->id): ?> selected <?php endif; ?>><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <option value="" style="font-style:italic;">Users Not Found</option>
                                                    <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
    
                                        <!-- Post Date -->
                                        <div class="row">
                                            <div class="">
                                                <div class="mb-3">
                                                    <?php $post_date_deadline = Carbon\Carbon::create($task->deadline);?>
                                                    <label for="post date">Post Date </label>
                                                    
                                                    <input type="date" name="deadline" value="<?php echo e($post_date_deadline->year); ?>-<?php echo e($post_date_deadline->format('m-d')); ?>" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
    
                                        <!-- Task id -->
                                        <input type="hidden" name="task_id" value="<?php echo e($task->id); ?>">
                                    </div>
    
                                    <!-- modal footer starts -->
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                      <input type="submit" class="btn btn-primary" value="Update">
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      <!-- Delete Project -->
                      <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($per == 18): ?>
                            <!-- Delete -->
                            <?php if($task->status == 1): ?>
                                <a class="delete-project-trigger" data='<?php echo e($task->id); ?>'><i class="far fa-trash-alt"  style="color:red;"></i></a> 
                            <?php endif; ?>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </td>

                </tr>

                <!-- Revine task modal -->
                <div class="modal" tabindex="-1" id="revine_task_modal_<?php echo e($task->id); ?>">
                  <div class="modal-dialog">
                    <div class="modal-content">

                      <div class="modal-header">
                        <h5 class="modal-title">Revine Project</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      
                      <form action="<?php echo e(route('task-revine')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">

                          <!-- Subject -->
                            <div class="row">
                                <div class="">
                                    <div class="mb-3">
                                        <input type="text" name="subject" class="form-control" value="" id="subject" placeholder="Subject" required>
                                    </div>        
                                </div>
                            </div>

                            <!-- Description -->
                            <div class="row">
                                <div class="">
                                    <div class="mb-3">
                                        <textarea name="description" id="description" class="form-control" cols="30" rows="5" placeholder="Description"></textarea>
                                    </div>
                                </div>
                            </div>

                            <!-- Files -->
                            <div class="row">
                                <div class="">
                                    <div class="mb-3">
                                        <label for="deadline">Upload files</label>
                                        <input type="file" name="attachments[]" class="form-control" multiple>
                                    </div>
                                </div>
                            </div>

                            <!-- Task id -->
                            <input type="hidden" name="main_task_id" value="<?php echo e($task->id); ?>">

                            <!-- Subtask id -->
                            <input type="hidden" name="sub_task_id" value="<?php echo e($sub_tasks->where('main_task', $task->id)->where('revined', 0)->pluck('id')->first()); ?>">
                        </div>


                        <!-- modal footer starts -->
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                          <input type="submit" class="btn btn-primary" value="Send">
                        </div>

                      </form>
                    </div>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
      </section>
</main>


<!-- Delete client confirm modal -->
<div class="modal" tabindex="-1" id="confirm-delete-project-modal">
  <div class="modal-dialog">
    <div class="modal-content">
        <form action="<?php echo e(route('delete-task')); ?>" method='POST' class='form'>
            <?php echo csrf_field(); ?>
          <div class="modal-body">
            <p id='message_in_confirm_delete_project_modal'></p>
            <input type='hidden' name='id' id='id_in_confirm_delete_project_modal' value=''>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-danger">Delete</button>
          </div>
      </form>
    </div>
  </div>
</div>

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gbsprojects/public_html/taskmanagement/resources/views/tasks.blade.php ENDPATH**/ ?>