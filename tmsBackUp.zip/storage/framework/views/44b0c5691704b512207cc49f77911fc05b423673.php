    <?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Container Main start-->
    <div class="main-container">
      <div id="Second-container2">
        <div class="row mt-4">
          <form action="<?php echo e(route('add_role_permissions')); ?>" method="POST" class="form">
            <?php echo csrf_field(); ?>
            <div>
              <h1 class="text-center">Role</h1>

            </div>
            <div class="mt-3 m-auto">
              <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Add Role</label>
                <input type="text" name="role" class="form-control" id="exampleFormControlInput1" placeholder="Role">
              </div>
              <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Role Description</label>
                <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="3"></textarea>
              </div>
            </div>

            <div class="m-auto mt-4">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col" width="20%">#</th>
                    <th scope="col" width="60%">Permission</th>
                    <th scope="col" width="20%">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if($permissions->count() != 0): ?>
                    <?php $no =1; ?>
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($no++); ?></th>
                        <td><?php echo e($permission->name); ?></td>
                        <td>
                          <div class="form-check">
                            <input class="form-check-input" name="permissions[]" type="checkbox" value="<?php echo e($permission->id); ?>" id="flexCheckChecked">
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>

            <div class="text-center my-4">
              <button type="submit" class="btn btn-info">Create</button>
            </div>
          </form>

        </div>
      </div>
      <!-- Create role and permsion ends -->
    </div>
  </div>

  <!-- JavaScript Bundle with Popper -->
  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script> -->

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\taskly\resources\views/roles/roles_view.blade.php ENDPATH**/ ?>