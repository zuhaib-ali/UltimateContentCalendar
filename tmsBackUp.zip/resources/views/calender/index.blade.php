@include("layouts.header")
<link rel="stylesheet" href="{{ asset('assets/style.css') }}">
<main class="container mt-5 pt-5">
    <!-- Show records by date selection -->
    <form class="form my-5" action="{{ route('record_on_date') }}" method="GET">
        <div class="row">
            <div class="form-group col-6">
                <lable for="start_date">Start Date</lable>
                <input type="date" name="start_date" class="form-control me-5" required>    
            </div>
            
            <div class="form-group col-6">
                <lable for="end_date">End Date</lable>
                <input type="date" name="end_date" class="form-control me-5" required>    
            </div>
        </div>
        <div style="width:100%; display:flex; justify-content:end; margin-top:12px;">
            <input type="submit" value="Show Record" class="btn btn-primary">
        </div>
    </form>
    
    
    <!-- Date from and to. -->
    <div class="">
        <p><b><i>{{ $from }}</i></b> to <b><i>{{ $to }}</i></b></p>
    </div>
    
    <div class="row">
        
        <!-- Clients -->
        <div class="col-lg-2 col-md-3 col-sm-12">
            <!--Filter By Clients-->
            <h5>Filter By Clients:</h4>
            @if($clients != null)
                <ul class="ul-padding-re" style="list-style-type:none;">
                    <li>
                        <div class="form-check form-switch">
                            <input type="checkbox" value="" class="form-check-input clientName dummy_calender_clients_all" checked/> 
                            <label class="label-client-name"> All </label> 
                        </div>
                    </li>
                    @foreach($clients as $client)
                        <li>
                            <div class="form-check form-switch">
                                <input type="checkbox" value="{{ $client->id }}" class="form-check-input clientName dummy_calender_client" checked/> 
                                <label class="label-client-name"> {{ $client->name }} </label> 
                            </div>
                        </li>
                    @endforeach
                </ul>
            @endif
            <hr>
            
            <!-- Filter By Project Assigned User -->
            <h5>Filter By Project Assigned To:</h5>
            @if($users)
                <ul class="ul-padding-re" style="list-style-type:none;">
                    @foreach($users as $user)
                        <li>
                            <div class="form-check form-switch">
                                <input type="checkbox" value="{{ $user->id }}" class="form-check-input clientName dummy_calender_user_project" checked/> 
                                <label class="label-client-name"> {{ $user->first_name }} {{ $user->last_name }} </label> 
                            </div>
                        </li>
                    @endforeach
                </ul>
            @endif
            
        </div>
        
        <!--overflow-x:scroll;-->
        <div class="col-lg-10 col-md-9 col-sm-12 pspsps" style="overflow-x:scroll;">
            <!-- 1 week -->
            <section id="second-container">
                <table class="table">
                    
                    <thead>
                        <tr class="row-2-color" id="dummy_calender_total_days">
                            <th scope="row" class="text-center bg-white client-left" >Clients</th>
                            @foreach($past_seven_days as $day)
                                <th scope="col" class="column1 text-center date-same-equal-class">{{ $day->format('D, d M') }}</th>
                                <th class="align-bottom text-center purple-type-color">caps</th>
                            @endforeach
                        </tr>
                    </thead>
                
                    <!-- Projects -->
                    <tbody class="clients_projects_table">
                        <!-- if clients and projects exists -->
                        @if($clients->count() != 0 && $projects != null)
                            <?php $client_index = 0;?>
                            @foreach($projects as $project)
                                <?php $project_index = 0; ?>
                                <tr data-client-row-id="{{ $clients[$client_index]->id }}" class="project_row">
                                    <!-- client -->
                                    <th class="tb-name-column"style="padding:5px !important;">{{ $clients[$client_index]->name }}</th>
                                    
                                    <!-- Projects-->
                                    @for($i=0; $i<=$calender_length; $i++)
                                        
                                        <!-- Projects -->
                                        <th colspan="2" class="px-0" >
                                            @foreach($project as $pro)
                                                @if(Carbon\Carbon::create($pro->deadline)->format('D, d M') == $past_seven_days[$i]->format('D, d M'))
                                                    <div style="display:flex; border:solid 1px grey; width:150px;" data-project-id="{{ $pro->id }}" data-user-id="{{ $pro->user_id }}" class="dummy_calender_project_view_modal_trigger">
                                                        <div style="background-color: {{ $status_colors->find($pro->status)->status_color }}; width:100px; word-break:break-all; border:1px solid #fff; margin:0px 0px;  padding:5px;">{{ $pro->name }} <br><i>({{ $pro->first_name }} {{ $pro->last_name }})</i></div>
                                                        
                                                        @if($pro->caption_status != null)
                                                            <div style="background-color: {{ $status_colors->find($pro->caption_status)->status_color }}; width:50px; word-break:break-all; border-top:1px solid #fff; border-bottom:1px solid #fff; border-right:1px solid #fff; padding:5px; margin:0px 0px;"></div>
                                                        @else
                                                            <div  style="padding:5px; margin:0px 0px; width:50px;"></div>
                                                        @endif
                                                    </div>  
                                                @endif
                                            @endforeach
                                        </th>
                                        
                                        @if($project_index >= $project->count())
                                            <?php break;?>
                                        @endif
                                    @endfor
                                </tr>
                                <?php $client_index++;?>
                            @endforeach
                        @else
                            <td colspan="15">No Proejct Found!</td>
                        @endif
                    </tbody>
              </table>
            </section>        
        </div>
    </div>
</main>


<!-- View Proejct Modal In Dummy Project -->
<div class="modal" tabindex="-1" id="dummy_calender_project_view_modal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Modal body text goes here.</p>
      </div>
      
      <div class="modal-footer">
          
        @foreach(json_decode(Session::get("user")->permissions_id, TRUE) as $per)
            @if($per == 17)
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" dummy-project-id="" id="dummy_calender_project_update_modal_trigger">Edit</button>  
            @endif
        @endforeach
        
        
        @foreach(json_decode(Session::get("user")->permissions_id, TRUE) as $per)
            @if($per == 22)
                <a href="" class="btn dummy_calender_status_button" id="dummy_calender_pending_button" style="background-color:{{ $colors[0]->status_color }}">{{ $colors[0]->status_name }}</a>
                <a href="" class="btn dummy_calender_status_button" id="dummy_calender_in_progress_button" style="background-color:{{ $colors[1]->status_color }}">{{ $colors[1]->status_name }}</a>
                <a href="" class="btn dummy_calender_status_button" id="dummy_calender_approved_button" style="background-color:{{ $colors[2]->status_color }}">{{ $colors[2]->status_name }}</a>
                <a href="" class="btn dummy_calender_status_button" id="dummy_calender_completed_button" style="background-color:{{ $colors[3]->status_color }}">{{ $colors[3]->status_name }}</a>
                <button data-bs-dismiss="modal" class="btn dummy_calender_status_button" id="dummy_calender_revised_button" style="background-color:{{ $colors[4]->status_color }}">{{ $colors[4]->status_name }}</button>
            @endif
        @endforeach
        

            
            
        
      </div>
    </div>
  </div>
</div>


<!-- Update Projct modal -->
<div class="modal" tabindex="-1" id="dummy_calender_project_update_modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Update Project</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form action="{{ route('update-task') }}" method="POST">
        @csrf
        <div class="modal-body">
            
            <!-- Task name -->
            <div class="row">
                <div class="">
                    <div class="mb-3">
                        <input type="text" name="task_name" class="form-control" value="" id="dummy_calender_update_task_name" placeholder="Task Name" required>
                    </div>        
                </div>
            </div>
            
            <!-- Projects -->
            <div class="row">
                <div class="">
                    <div class="mb-3">
                        <label for="roles">Projects</label>
                        <select name="project_id" id="dummy_calender_update_project" class="form-control" required></select>
                    </div>
                </div>
            </div>
            
            <!-- Description -->
            <div class="row">
                <div class="">
                    <div class="mb-3">
                        <textarea name="description" id="dummy_calender_update_description" class="form-control" cols="30" rows="5" placeholder="Editor's Description"></textarea>
                    </div>
                </div>
            </div>

            <!-- Caption -->
            <div class="row">
                <div class="">
                    <div class="mb-3">
                        <textarea name="caption" id="dummy_calender_update_caption" class="form-control" cols="30" rows="5" placeholder="Post Caption"></textarea>
                    </div>
                </div>
            </div>
            
            <!-- Caption status -->
            <div class="row">
                <div class="">
                    <div class="mb-3">
                        <select class="form-control" name="caption_status" id="dummy_calender_update_caption_status"></select>
                    </div>
                </div>
            </div>

            <!-- Assigend to -->
            <div class="row">
                <div class="">
                    <div class="mb-3">
                        <label for="roles">Assigned To</label>
                        <select name="user_id" id="dummy_calender_update_user" class="form-control" required></select>
                    </div>
                </div>
            </div>

            <!-- Post Date -->
            <div class="row">
                <div class="">
                    <div class="mb-3">
                        <label for="post date">Post Date</label>
                        <input type="date" name="deadline" value="" id="dummy_calender_update_post_date" class="form-control" required>
                    </div>
                </div>
            </div>

            <!-- Task id -->
            <input type="hidden" name="task_id" id="dummy_calender_update_task_id" value="">
        </div>

        <!-- modal footer starts -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-primary" value="Update">
        </div>
      </form>
    </div>
  </div>
</div>


<!-- Revine task modal In Dummy Calender -->
<div class="modal" tabindex="-1" id="revine_task_modal_dummy_calender">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Revine Project</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      
      <form action="{{ route('task-revine') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="modal-body">

          <!-- Subject -->
            <div class="row">
                <div class="">
                    <div class="mb-3">
                        <input type="text" name="subject" class="form-control" value="" id="subject" placeholder="Subject" required>
                    </div>        
                </div>
            </div>

            <!-- Description -->
            <div class="row">
                <div class="">
                    <div class="mb-3">
                        <textarea name="description" id="description" class="form-control" cols="30" rows="5" placeholder="Description"></textarea>
                    </div>
                </div>
            </div>

            <!-- Files -->
            <div class="row">
                <div class="">
                    <div class="mb-3">
                        <label for="deadline">Upload files</label>
                        <input type="file" name="attachments[]" class="form-control" multiple>
                    </div>
                </div>
            </div>

            <!-- Task id -->
            <input type="hidden" name="main_task_id" id="revine_project_task_id_dummy_calender" value="">

            <!-- Subtask id -->
            <input type="hidden" name="sub_task_id" value="{{-- $sub_tasks->where('main_task', $task->id)->where('revined', 0)->pluck('id')->first() --}}">
        </div>


        <!-- modal footer starts -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-primary" value="Send">
        </div>

      </form>
    </div>
</div>
                

@include("layouts.footer")