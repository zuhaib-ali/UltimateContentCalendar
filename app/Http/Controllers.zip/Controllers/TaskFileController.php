<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TaskFileController extends Controller
{
    // task calendar wise
    public function task_calender_wise()
    {
        // $tasks = DB::table('tasks')->get();
        $tasks      =   DB::table('tasks')->get();
        $projects   =   DB::table('projects')->get();
        $users      =   DB::table('users')->where('role_id', '!=', 1)->get();
        return view('calender.calender', compact('tasks','projects','users'));
    }


    // get tasks for calendar
    public function get_tasks_for_calender()
    {
        if(session()->get('user')->role_id == 1){
            return DB::table('tasks')
            ->join('users','tasks.user_id','users.id')
            ->join('projects','tasks.project_id','projects.id')
            ->join('colors', 'tasks.status', 'colors.id')
            ->select(
                'tasks.*',
                'colors.status_color as color',
                'users.first_name as fname',
                'users.last_name as lname',
                'projects.name as project_name'
                )
            ->get();
        }else{
            return DB::table('tasks')
            ->join('users','tasks.user_id','users.id')
            ->join('projects','tasks.project_id','projects.id')
            ->join('colors', 'tasks.status', 'colors.id')
            ->select(
                'tasks.*', 
                'colors.status_color as color',
                'users.first_name as fname',
                'users.last_name as lname',
                'projects.name as project_name'
                )
            ->where('user_id',session()->get('user')->id)
            ->get();
        }
    }

    // Get task deatil for calendar
    public function get_task_detail_for_calender($id)
    {
        $task   =    DB::table('tasks')
            ->join('task_files as tf', 'tasks.id', 'tf.task_id')
            ->join('users','tasks.user_id','users.id')
            ->join('colors', 'tasks.status', 'colors.id')
            ->select(
                'tasks.*',
                'tf.file_name as file',
                'colors.status_color as color',
                'colors.id as color_id',
                'colors.status_name as status_name',
                'users.first_name as fname',
                'users.last_name as lname'
            )
            ->where(['tasks.id' => $id])
            ->first();

        if($task != NULL){
            return $task;
        }
        elseif ($task == NULL) {
            return DB::table('tasks')
            ->join('colors', 'tasks.status', 'colors.id')
            ->join('users','tasks.user_id','users.id')
            ->select(
                'tasks.*',
                'colors.status_color as color',
                'colors.id as color_id',
                'colors.status_name as status_name',
                'users.first_name as fname',
                'users.last_name as lname'
            )
            ->where(['tasks.id' => $id])
            ->first();
        }
    }


    // Download file
    public function download_file($var)
    {
        $file = public_path("task_files") . "/" . $var;
        $headers = array(
            "Content-Type : multipart/form-data",
        );
        return response()->download($file, $var, $headers);
    }


    // Change status
    public function change_status($status, $task_id)
    {
        $update = DB::table('tasks')->where('id', $task_id)->update(['status' => 3]);
        if ($update == true) {
            return back();
        } else {
            echo 'error';
        }
    }
    
    public function task_status_to_progress($task_id){
        $update = DB::table('tasks')->where('id', $task_id)->update(['status' => 2]);
        if ($update == true) {
            return back();
        } else {
            echo 'error';
        }
    }
    
    public function task_status_to_complete($task_id){
        $update = DB::table('tasks')->where('id', $task_id)->update(['status' => 4]);
        if ($update == true) {
            return back();
        } else {
            echo 'error';
        }
    }
}
