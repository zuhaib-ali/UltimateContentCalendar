<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Models\Task;
use App\Models\Project;
use App\Models\User;
use App\Models\SubTask;
use App\Models\TaskFile;
use App\Models\Color;
// use DB;

class TaskController extends Controller
{

    // Index
    public function index(Request $request){
        if($request->session()->get("user")->role_id == 1){
            return view("tasks", [
                "tasks" => Task::join("projects", "tasks.project_id", "=", "projects.id")
                ->join("users", "tasks.user_id", "=", "users.id")
                ->join("colors", "tasks.status", "=", "colors.id")
                ->select(
                    "tasks.*", 
                    "projects.name as project_name",
                    "projects.id as project_id",
                    "projects.deadline as project_deadline",
                    "users.first_name",
                    "users.last_name",
                    "colors.id as color_id",
                    "colors.status_name",
                    "colors.status_color"
                )
                ->get(),

                "sub_tasks" => SubTask::join("colors", "sub_tasks.status", "=", "colors.id")
                ->join("task_files", "sub_tasks.id", "=", "task_files.id")
                ->select(
                    "sub_tasks.*",
                    "colors.id as color_id",
                    "colors.status_name",
                    "colors.status_color"
                )
                ->get(),
                "projects" => Project::all(),
                "users" => User::where("id", "!=", 1)->get(),
                "colors" => Color::all(),
                "task_files" => TaskFile::all(),
            ]);

        }else{
            return view("tasks", [
                "tasks" => Task::join("projects", "tasks.project_id", "=", "projects.id")
                ->join("users", "tasks.user_id", "=", "users.id")
                ->join("colors", "tasks.status", "=", "colors.id")
                ->where("user_id", $request->session()->get("user")->id)
                ->select(
                    "tasks.*", 
                    "projects.name as project_name",
                    "projects.id as project_id",
                    "projects.deadline as project_deadline",
                    "users.first_name",
                    "users.last_name",
                    "colors.id as color_id",
                    "colors.status_name",
                    "colors.status_color"
                )
                ->get(),
                
                "projects" => Project::all(),
                "sub_tasks" => SubTask::join("colors", "sub_tasks.status", "=", "colors.id")
                ->join("task_files", "sub_tasks.id", "=", "task_files.id")
                ->select(
                    "sub_tasks.*",
                    "colors.id as color_id",
                    "colors.status_name",
                    "colors.status_color"
                )
                ->get(),
                "users" => User::where("id", "!=", 1)->get(),
                "colors" => Color::all(),
                "task_files" => TaskFile::all(),
            ]);
        }
    }

    // Create
    public function create(Request $request){
        $task_created_date = '';
        $task = '';
        // validating
        if($request->auto_assign == 1){
            $users = DB::table('tasks')
            ->join('users', 'tasks.user_id','users.id')
            ->join('colors', 'tasks.status','colors.id')
            ->select(
                'tasks.deadline',
                'users.first_name as fname',
                'users.last_name as lname',
                'colors.status_name as project_status'
                )
            ->where("tasks.status",1)
            ->orWhere("tasks.status",2)
            ->orderBy("tasks.deadline","desc")
            ->get();
            // dd($users[0]->deadline);
            $deadline = $users[0]->deadline;
            
            foreach($users as $key => $task){
                if($task->deadline == $deadline){
                    echo $task->deadline;
                    return false;
                }else{
                    echo $task->fname;
                    echo "</br>";
                }
            }
        }
        
        
        $create_task = '';
        $request->validate([
            "task_name" => "required",
            "description" => "required",
            "project_id" => "required",
            "user_id" => "required",
            'deadline' => 'required|after_or_equal:today',
        ]);
        
        if($request->deadline > Project::find($request->project_id)->deadline){
            return back()->with("task_danger", "Task deadline must be before or equal to project deadline");
        }
        // creating task
        
        
        
        
        if($request->created_date != NULL){
            $task_created_date = $request->created_date;
            $task = [
                "name" => $request->task_name,
                "description" => $request->description,
                "project_id" => $request->project_id,
                "user_id" => $request->user_id,
                "pending_date" => now(),
                "deadline" => $request->deadline,
                "created_date"=>$request->created_date . ' ' . date("h:i:s")
            ];
            $create_task = DB::table('tasks')->insertGetId($task);
            // dd($task);
        }else{
            $task_created_date = NULL;
            $task = [
                "name" => $request->task_name,
                "description" => $request->description,
                "project_id" => $request->project_id,
                "user_id" => $request->user_id,
                "pending_date" => now(),
                "deadline" => $request->deadline,
                "created_date"=> now()
            ];
            $create_task = DB::table('tasks')->insertGetId($task);
            
        }
        
        // $create_task = DB::table('tasks')->insert($task);
        
        // if files exists, store files.
        if($request->task_files != null){
            foreach($request->task_files as $file_name){
                TaskFile::Create([
                    "file_name" => $file_name->getClientOriginalName(),
                    "task_id" => $create_task,
                ]);
    
                $file_name->move(public_path("task_files"), $file_name->getClientOriginalName());    
            }
        }
        if($create_task == true){
            return back()->with("task_success", "Task ".$request->task_name." created.");
        }else{
            return back()->with("task_danger", "Task failed to created.");
        }
    }
    
    // Update
    public function update(Request $request){
        $request->validate([
            "task_name" => "required",
            "description" => "required",
            "project_id" => "required",
            "user_id" => "required",
            "deadline" => "required|after_or_equal:today",
        ]);
        if($request->deadline > Project::find($request->project_id)->deadline){
            return back()->with("task_danger", "Task deadline must be before or equal to project deadline");
        }
        $task = Task::find($request->task_id);
        $task_name = $task->name;

        $task->name = $request->task_name;
        $task->description = $request->description;
        $task->project_id = $request->project_id;
        $task->user_id = $request->user_id;
        $task->deadline = $request->deadline;

        if($task->update()){
            return back()->with("task_info", "Task ".$request->task_name." updated.");
        }else{
            return back()->with("task_danger", "Task failed to updated.");
        }
    }

    // Delete
    public function delete(Request $request){
        $task = Task::find($request->task_id);
        $task_name = $task->name;
        if($task->delete()){
            return back()->with("task_info", "Task ".$task_name." deleted.");
        }else{
            return back()->with("task_danger", "Task failed to delete.");
        }
    }

    // Update task status .
    public function updateStatus(Request $request){
        $task =  Task::find($request->task_id);
        $task_name = $task->name;

        // In progress status
        if($request->status_id == 2){
            $task->status = (int)$request->status_id;
            $task->in_progress_date = now();
            if($task->update()){
                return back()->with("task_info", "From now task ".$task_name." is in process status.");
            }
        
        // Approve status
        }elseif($request->status_id == 3){
            $task->status = (int)$request->status_id;
            $task->approve_date = now();
            if($task->update()){
                return back()->with("task_info", "Task ".$task_name." Approved.");
            }
        
        // Complete status
        }elseif($request->status_id == 4){
            $task->status = (int)$request->status_id;
            $task->complete_date = now();
            if($task->update()){
                return back()->with("task_success", "Task ".$task_name." sent for approval.");
            }
        
        // Pending status
        }elseif($request->status_id == 1){
            $task->status = (int)$request->status_id;
            $task->pending_date = now();
            if($task->update()){
                return back()->with("task_warning", "From now task ".$task_name." is in process status.");
            }
        
        // Revine status
        }elseif($request->status_id == 5){
            $task->status = (int)$request->status_id;
            $task->revine = now();
            $task->parent_id += 1;
            if($task->update()){
                return back()->with("task_danger", "Task ".$task_name." rejected.");
            }
        }
    }

    // Add task attachments
    public function addTaskAttachments(Request $request){
        $task_attachments = false;
        foreach($request->task_attachments as $attachment){
            $file_created = TaskFile::create([
                "file_name" => $attachment->getClientOriginalName(),
                "task_id" => $request->task_id,
            ]);

            if($file_created){
                $task_attachments = true;

                $file_stored = $attachment->move(public_path("task_files"), $attachment->getClientOriginalName());
                if($file_stored){
                    $task_attachments = true;
                }else{
                    $task_attachments = false;
                }

            }else{
                $task_attachments = false;
            }
            
        }
        if($task_attachments){
            return back()->with("task_success", "Attachments added");
        }else{
            return back()->with("task_danger", "Failed to add task attachments.");
        }
    }

    // Download task file
    public function downloadTaskFile(Request $request){
        $file = public_path("task_files")."/".$request->task_file_name;
        $headers = array(
            "Content-Type : multipart/form-data",
        );
        return response()->download($file, $request->task_file_name, $headers);   
    }   


    public function getTask(Request $request){
        return $request->data;
    }
}
