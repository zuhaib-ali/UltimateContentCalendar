<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Project;
use App\Models\Task;
use App\Models\User;

class ProjectController extends Controller
{
    // Index
    public function index(){
        return view("projects", [
            "projects" => Project::all(),
            "users" => User::all(),
        ]);
    }

    // Create
    public function create(Request $request){
        $request->validate([
            "project_name" => "required",
            "description" => "required",
            "deadline" => "required|after_or_equal:today",
        ]);
        $create_project = Project::create([
            "name" => $request->project_name,
            "description" => $request->description,
            "deadline" => $request->deadline,
        ]);

        if($create_project){
            return redirect()->route("projects")->with("project_success", "Project ".$request->project_name." created.");
        }else{
            return redirect()->route("projects")->with("project_danger", "Project failed to created.");
        }
        return $request->all();
    }

    // Update
    public function update(Request $request){
        $request->validate([
            "project_name" => "required",
            "description" => "required",
            "deadline" => "required|after_or_equal:today",
        ]);
        
        $project = Project::find($request->project_id);

        $project_name = $project->name;

        $project->name = $request->project_name;
        $project->description = $request->description;
        $project->deadline = $request->deadline;

        if($project->update()){
            return redirect()->route("projects")->with("project_info", "Project ".$project_name." updated.");
        }else{
            return redirect()->route("projects")->with("project_danger", "Project failed to updated.");
        }
    }

    // Delete
    public function delete(Request $request){
        $project = Project::find($request->project_id);
        $project_name = $project->name;

        if($project->delete()){
            return redirect()->route("projects")->with("project_info", "Project ".$project_name." deleted.");
        }else{
            return redirect()->route("projects")->with("project_danger", "Project failed to delete.");
        }
    }
}
