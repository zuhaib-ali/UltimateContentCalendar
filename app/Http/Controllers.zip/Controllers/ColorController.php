<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Color;

class ColorController extends Controller
{
    public function setColors(Request $request){
        if(Color::all()->count() == 0){
            $color_created = Color::create([
                "status_name" => "pending",
                "status_color" => $request->pending_color

            ]);

            if($color_created){
                Color::create([
                    "status_name" => "in_progress",
                    "status_color" => $request->in_progress_color
    
                ]);
                
            }else{
                return redirect()->route("settings")->with("colors", "Failed set color for pending");
            }

            if($color_created){
                
                Color::create([
                    "status_name" => "approve",
                    "status_color" => $request->approve_color

                ]);
                
            }else{
                return redirect()->route("settings")->with("colors", "Failed set color for process");
            }

            if($color_created){
                Color::create([
                    "status_name" => "complete",
                    "status_color" => $request->complete_color
    
                ]);
                
            }else{
                return redirect()->route("settings")->with("colors", "Failed set color for approve");
            }

            if($color_created){
                $color_created = Color::create([
                    "status_name" => "reject",
                    "status_color" => $request->reject_color
    
                ]);
            }else{
                return redirect()->route("settings")->with("colors", "Failed set color for compelet");
            }


            if($color_created){
                return redirect()->route("settings")->with("colors", "Colors created successfully");
            }else{
                return redirect()->route("settings")->with("colors", "Failed to set color for Reject");
            }
        }
        
        foreach(Color::all() as $color){
            if($color->id == 1){
                if($request->pending_color != null){
                    $color->status_color = $request->pending_color;
                }
            }

            if($color->id == 2){
                if($request->in_progress_color != null){
                    $color->status_color = $request->in_progress_color;
                }
                
            }

            if($color->id == 3){
                if($request->approve_color != null){
                    $color->status_color = $request->approve_color;
                }
                
            }

            if($color->id == 4){
                if($request->complete_color != null){
                    $color->status_color = $request->complete_color;
                }
                
            }

            if($color->id == 5){
                if($request->reject_color != null){
                    $color->status_color = $request->reject_color;
                }
            }
            $color->update();
        }

        return redirect()->route("settings")->with("colors", "Colors updated");
    }
}
