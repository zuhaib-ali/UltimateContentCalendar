<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Comment;

class CommentController extends Controller
{
    public function index(){
        return view("commentingSystem.comment");
    }
    
    public function create(Request $request){
        $request->validate([
            "platform" => "required",
            "comment_type" => "required",
            "url" => "required|url",
            "actual_comment" => "required"
        ]);
        
        $comment = Comment::create([
            "platform" => $request->platform,
            "comment_type" => $request->comment_type,
            "url" => $request->url,
            "actual_comment" => $request->actual_comment,
            "feedback" => $request->feedback,
        ]);   
        
        if($comment){
            return back()->with("comment_success", $request->comment_type." sent");
        }else{
            return back()->with("comment_error", "Failed to send ".$request->comment_type);
        }
    }
}
