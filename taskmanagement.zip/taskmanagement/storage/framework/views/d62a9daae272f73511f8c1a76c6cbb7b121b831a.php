<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="container mt-5 pt-5">
<section id="second-container3">
        <div class="main-container-two">
            <div class="welcome-note-two">
              <h4>Projects, <?php echo e($tasks->count()); ?></h4>
            </div>
          <div>
          </div>
        </div>
        <!-- TABLES START -->
        <table class="table table-striped table-hover table-bordered mt-5">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Project</th>
              <th scope="col">Client</th>
              <th scope="col">Status</th>
              <th scope="col">Created At</th>
              <th scope="col" style="width:130px;">Actions</th>
            </tr>
          </thead>

          <tbody>
            <?php $no =1; ?>
              <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="notify_tr" data="<?php echo e($task->id); ?>" style="background-color:#ebfaff;">
                  <th scope="row"><?php echo e($no++); ?></th>
                  <td><?php echo e($task->name); ?></td>
                  <td><?php echo e($task->project_name); ?></td>
                  <td><span style="color:<?php echo e($task->status_color); ?>; font-weight:bold; text-transform:uppercase"><?php echo e($task->status_name); ?></span></td>
                  <td><?php echo e(substr($task->created_date,0,11)); ?></td>
                  <td> <a href='javascript:void(0)' class="read_task" style='color:black;'><i class='bx bx-check-double' style='font-size:28px;'></i></a></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <!-- TABLES END -->
      </section>
</main>

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/gbsprojects/public_html/taskmanagement/resources/views/notified_tasks.blade.php ENDPATH**/ ?>