<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="container mt-5 pt-5">
<section id="second-container3">
    <center><h2 style="font-weight:300px;">USERS</h2></center>
    <div class="main-container-two">
      <div class="welcome-note-two"></div>
      
      <div>
          <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($per == 23): ?>
              <button class="btn btn-outline-success" data-bs-toggle="modal"  data-bs-target="#add_user" type="button">Add User</button>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          
        
        <!-- Add user modal -->
            <div class="modal" tabindex="-1" id="add_user">
              <div class="modal-dialog">
                <div class="modal-content">
    
                  <div class="modal-header">
                    <h5 class="modal-title">Add User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  
                  <form action="<?php echo e(route('add_user')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                      <div class="row">
                        <div class="col-6">
                          <div class="mb-3">
                            <label for="first_name">First Name</label>
                            <input type="text" name="first_name" class="form-control" value="" id="first_name" required>
                          </div>        
                        </div>
    
                        <div class="col-6">
                          <div class="mb-3">
                            <label for="last_name">Last Name</label>
                            <input type="text" name="last_name" class="form-control" value="" id="last_name" required>
                          </div>
    
                        </div>
                      </div>
    
                      <div class="row">
                        <div class="col-7">
                          <div class="mb-3">
                          <label for="email">E-Mail</label>
                            <input type="email" name="email" class="form-control" value="" id="email" placeholder="E-Mail" required>
                          </div>
                        </div>
    
                        <div class="col-5">
                          <div class="mb-3">
                            <label for="roles">Roles</label>
                            <select name="role_id" id="roles" class="form-control">
                              <?php if($roles->count() != 0): ?>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($role->id); ?>"><?php echo e($role->role); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                                <option value="" style="font-style:italic;">Roles Not Found</option>
                              <?php endif; ?>
                            </select>
                          </div>
                        </div>
                      </div>
    
                      <!-- Address -->
                      <div class="row">
                        <div class="col-12">
                          <div class="mb-3">
                            <label for="address">Address</label>
                            <textarea name="address" id="address" cols="30" rows="3" class="form-control"></textarea>
                          </div>
                        </div>
                      </div>
    
                      <!-- Password -->
                      <div class="row add_user_password">
                        <div class="col-12">
                          <div class="mb-3">
                            <label for="password">Password</label>
                            <input type="password" name="password" class="form-control" value="" id="password" placeholder="Password" required>
                            <input type="checkbox" id="show_password"> <span style="color:grey;"> Show password</span>
                          </div>
                        </div>
                      </div>
    
                      <!-- Image -->
                      <div class="row">
                        <div class="col-12">
                          <div class="mb-3">
                            <label for="profile_image">Profile image</label>
                            <input type="file" name="profile_image" class="form-control" id="profile_image">
                          </div>
                        </div>
                      </div>
    
                    </div>
                    <!-- Modal body ends -->
    
                    <!-- modal footer starts -->
                    <div class="modal-footer">
                      <!--<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
                      <input type="submit" class="btn btn-sm btn-outline-primary" value="Add">
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <!-- add user modal ends -->
      </div>
    
    </div>
        
        <br><br>
        <table id="users_datatable" class="display">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Profile</th>
                    <th scope="col">Name</th>
                    <th scope="col">E-Mail</th>
                    <th scope="col">Address</th>
                    <th scope="col">Role</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            
            <tbody>
                <?php if($users->count() != 0): ?>
            <?php $no =1; ?>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($no++); ?></td>
                  <?php if($user->img != null): ?>
                    <td><img src="<?php echo e(asset('profile_images')); ?>/<?php echo e($user->img); ?>" style="width:80px; height:80px; border-radius:50px;"></td>
                  <?php else: ?>
                    <td><img src="https://th.bing.com/th/id/OIP.iYpFSu2O2kVP1OptEdJ-uwHaHx?w=180&h=189&c=7&r=0&o=5&pid=1.7" style="width:80px; height:80px; border-radius:50px;"></td>
                  <?php endif; ?>
                  
                  <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                  <td><?php echo e($user->email); ?></td>
                  <td><?php echo e($user->address); ?></td>
                  <?php if($user->role_id == null): ?>
                    <td>NA</td>
                  <?php else: ?>
                    <td><span style="background-color:skyblue; color:white; border-radius:50px; padding:5px 10px;"><?php echo e($user->role); ?></span></td>
                  <?php endif; ?>                  
                  <td>
                      
                    <!-- Edit User -->
                    <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($per == 20): ?>
                            <a href="#" class="me-2"><i class="far fa-edit open" data-bs-toggle="modal" data-bs-target="#edit_modal_<?php echo e($user->id); ?>"></i></a>
                            <!-- Edit modal -->
                            <div class="modal" tabindex="-1" id="edit_modal_<?php echo e($user->id); ?>">
                              <div class="modal-dialog">
                                <div class="modal-content">
    
                                  <div class="modal-header">
                                    <h5 class="modal-title">Edit - <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                  </div>
                                  
                                  <form action="<?php echo e(route('update_user')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                      <div class="row">
                                        <div class="col-4">
                                          <p>Firsn Name</p>
            
                                        </div>
                                        <div class="col-8">
                                          <div class="mb-3">
                                            <input type="text" name="first_name" class="form-control" value="<?php echo e($user->first_name); ?>" id="exampleFormControlInput1" placeholder="First Name">
                                          </div>
            
                                        </div>
                                      </div>
                                      <div class="row">
                                        <div class="col-4">
                                          <p>Last Name</p>
            
                                        </div>
                                        <div class="col-8">
                                          <div class="mb-3">
                                            <input type="text" name="last_name" class="form-control" value="<?php echo e($user->last_name); ?>" id="exampleFormControlInput1" placeholder="Last Name">
                                          </div>
            
                                        </div>
                                      </div>
    
                                      <div class="row">
                                        <div class="col-4">
                                          <p>E-Mail</p>
            
                                        </div>
                                        <div class="col-8">
                                          <div class="mb-3">
                                            <input type="text" name="email" class="form-control" value="<?php echo e($user->email); ?>" id="exampleFormControlInput1" placeholder="Last Name">
                                          </div>
            
                                        </div>
                                      </div>
    
                                        <!-- ADDRESS -->
                                      <div class="row">
                                        <div class="col-4">
                                          <p>Address</p>
                                        </div>
                                        <div class="col-8">
                                          <div class="mb-3">
                                            <textarea name="address" id="" cols="30" rows="4" class="form-control"><?php echo e($user->address); ?></textarea>
                                          </div>
                                        </div>
                                      </div>
    
                                      <div class="row">
                                        <div class="col-4">
                                          <p>Roles</p>
                                        </div>
    
                                        <div class="col-8">
                                          <div class="mb-3">
                                            <select name="role" id="" class="form-control">
                                              <option value="" style="font-style:italic;">None</option>
                                              <?php if($roles->count() != 0): ?>
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option value="<?php echo e($role->id); ?>" <?php if($user->role_id == $role->id): ?> selected <?php endif; ?>><?php echo e($role->role); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              <?php else: ?>
                                                <option value="" style="font-style:italic;">Roles Not Found</option>
                                              <?php endif; ?>
                                            </select>
                                          </div>
                                        </div>
                                      </div>
                                      
                                      <div class="row">
                                        <div class="col-4">
                                          <p>Image</p>
                                        </div>
                                        <div class="col-8">
                                          <div class="mb-3">
                                            <input type="file" value="" name="profile_image" class="form-control">
                                            <input type="hidden" name="user_old_profile" value="<?php echo e($user->img); ?>">
                                          </div>
                                        </div>
                                      </div>
    
                                    </div>
                                    <!-- Modal body ends -->
                                    
    
                                    <!-- Role id -->
                                    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
    
                                    <!-- modal footer starts -->
                                    <div class="modal-footer">
                                      <!--<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
                                      <input type="submit" class="btn btn-primary" value="Update">
                                    </div>
                                    
                                  </form>
                                </div>
                              </div>
                            </div>
                            |
                            <!-- edit modal ends -->
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <!-- Delete User -->
                    <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($per == 21): ?>
                            <!-- Delete user -->
                            <a class="delete-user-trigger" data='<?php echo e($user->id); ?>'><i class="far fa-trash-alt"  style="color:red;"></i></a> 
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
      </section>
</main>

<!-- Confirm Delete User -->
<div class="modal" tabindex="-1" id="confirm-delete-user-modal">
  <div class="modal-dialog">
    <div class="modal-content">
        <form action="<?php echo e(route('delete_user')); ?>" method='POST' class='form'>
            <?php echo csrf_field(); ?>
          <div class="modal-body">
            <p id='message_in_confirm_delete_user_modal'></p>
            <input type='hidden' name='id' id='id_in_confirm_delete_user_modal' value=''>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
          </div>
      </form>
    </div>
  </div>
</div>

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gbsprojects/public_html/taskmanagement/resources/views/users.blade.php ENDPATH**/ ?>