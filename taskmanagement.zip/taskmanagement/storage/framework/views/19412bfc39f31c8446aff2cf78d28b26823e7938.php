<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="container mt-5 pt-5">
<section id="second-container3">
        <center><h2 style="font-weight:400;">CLIENTS</h2></center>
        <div class="main-container-two">
            <div class="welcome-note-two"></div>
            
            <div>
                <!-- Button trigger modal -->
                <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($per == 7): ?>
                    <button class="btn btn-outline-success" data-bs-toggle="modal"  data-bs-target="#add_project" type="button">Add Client</button>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <!-- Modal -->
                <div class="modal fade" id="add_project" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="<?php echo e(route('add-project')); ?>" method="POST" class='form' enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Create New Client</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                                <!-- Client Name -->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <label for="">First Name</label>
                                            <input type="text" name="first_name" class="form-control" value="" placeholder=" " required>
                                        </div>        
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <label for="">Last Name</label>
                                            <input type="text" name="last_name" class="form-control" value="" placeholder=" " required>
                                        </div>        
                                    </div>
                                </div>
                                
                                <!-- E-Mail -->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <label for="">E-Mail</label>
                                            <input type="email" name="email" class="form-control" value="" placeholder="" required>
                                        </div>        
                                    </div>
                                </div>
                                
                                <!-- Password -->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <label for="">Password</label>
                                            <input type="password" name="password" id="client_password" class="form-control" value="" placeholder="" required>
                                            <span style="color:lightgrey; font-size:12px;"><input type="checkbox" id="show_client_password" style="color:lightgrey;"> Show Password</span>
                                        </div>        
                                    </div>
                                </div>
                                
                                <!-- Client Description-->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <label for="">Description</label>
                                            <textarea name="description" id="description" class="form-control" cols="30" rows="5" placeholder="Description"></textarea>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Role -->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <label for="">Role</label>
                                            <select class="form-control" name="client_role">
                                                <?php if($roles->count() != 0): ?>
                                                    <option value="" disabled selected hidden> -- Select Role -- </option>
                                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->role); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                <?php else: ?>
                                                    <option value="" disabled selected hidden> -- No Role Found! -- </option>
                                                <?php endif; ?>
                                                
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Users -->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <label for="">Users</label>
                                            <select name="user" class="form-control">
                                                <?php if($users->count() != 0): ?>
                                                    <option value="" disabled selected hidden>-- Select User --</option>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></option>    
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <option value="" disabled selected hidden>-- No User Found! --</option>
                                                <?php endif; ?>
                                                
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Profile -->
                                <div class="row">
                                    <div class="">
                                        <div class="mb-3">
                                            <label for="">Client Profile</label>
                                            <input type="file" name="client_profile" class="form-control">
                                        </div>
                                    </div>
                                </div>
                          </div>
                          
                          <div class="modal-footer">
                            <!--<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
                            <button type="submit" class="btn btn-primary btn-sm">Create</button>
                          </div>
                          
                      </form>
                    </div>
                  </div>
                </div>
          </div>
        </div>
        
        <br><br>
        
        <table id="clients_datatable" class="display">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Profile</th>
                    <th scope="col">Client</th>
                    <th scope="col">E-Mail</th>
                    <th scope="col" style="width:130px;">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if($client_users->count() == 0): ?>
            <tr >
                <td colspan="6">NO CLIENT FOUND!</td>
            </tr>
                
            <?php else: ?>
                <?php $no =1; ?>
                <?php $__currentLoopData = $client_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    
                    <?php if($client->img != null): ?>
                        <td><img src="<?php echo e(asset('profile_images')); ?>/<?php echo e($client->img); ?>" style="width:80px; height:80px; border-radius:50px;"></td>
                    <?php else: ?>
                        <td><img src="https://th.bing.com/th/id/OIP.iYpFSu2O2kVP1OptEdJ-uwHaHx?w=180&h=189&c=7&r=0&o=5&pid=1.7" style="width:80px; height:80px; border-radius:50px;"></td>
                    <?php endif; ?>
                    
                    <td><?php echo e($client->first_name); ?> <?php echo e($client->last_name); ?></td>
                    <td><?php echo e($client->email); ?></td>
                    <td>
                        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($per == 13): ?>
                                <!-- View Project -->
                                <a class="view_project_trigger" data="<?php echo e($client->client_id); ?>"><i class="far fa-eye" ></i></a>|    
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <!-- Edit modal -->
                        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($per == 14): ?>
                                <a class="edit_project_trigger" data="<?php echo e($client->client_id); ?>" data-bs-toggle="modal"><i class="far fa-edit open" ></i></a>|
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <!-- Delete Client -->
                        <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($per == 15): ?>
                                <a class="delete-client-trigger" data='<?php echo e($client->client_id); ?>'><i class="far fa-trash-alt"  style="color:red;"></i></a> 
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
      </section>
</main>


<!-- View project modal -->
<div class="modal" tabindex="-1" id="view_project_modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title" style="text-transform:uppercase;"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container-fluid">
            <div class="row mb-3">
                <div class="col-md-8 col-8">
                    
                    <div class="d-flex gap-2">
                        <p style="font-weight:600; margin:0; text-transform: uppercase;">E-Mail: </p>
                        <em id="client_view_email"></em>
                    </div>
                </div>
                <div class="col-md-4 col-4">    
                    <div class="d-flex gap-2">
                        <p style="font-weight:600; margin:0; text-transform: uppercase;">Role: </p>
                        <em id="client_view_role"></em>
                    </div>
                </div>
                
                
            </div>
            <div class="row mb-3">
                <div class="col-md-12">
                    
            
                    <div>
                        <p style="font-weight:600; margin:0; text-transform: uppercase;">Description: </p>
                        <em id="client_view_descritpion"></em>
                    </div>
                </div>
                
            </div>
            <div class="row">
            <div class="col-md-12">
                <div>
                    <p style="font-weight:600; margin:0; text-transform: uppercase;">Permissions: </p>
                    <ul id="client_view_permissions" style="font-style: italic;"></ul>
                </div>
            </div>
            
            </div>
        </div>
      </div>

      <!-- Modal footer -->
      <!--<div class="modal-footer">-->
      <!--  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
      <!--</div>-->
    </div>
  </div>
</div>


<!-- Edit project modal -->
<div class="modal" tabindex="-1" id="edit_project_modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form action="<?php echo e(route('update-project')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal-body">

          <!-- First Name -->
          <div class="form-group mb-3">
            <label for="">First Name</label>
            <input type="text" placeholder="First Name" id="edit_project_first_name" name="first_name" value="" class="form-control">
          </div>
          
          <!-- Last Name -->
          <div class="form-group mb-3">
            <label for="">Last Name</label>
            <input type="text" placeholder="Last Name" id="edit_project_last_name" name="last_name" value="" class="form-control">
          </div>

          <!-- Description -->
          <div class="form-group mb-3">
            <label for="">Description</label>
            <textarea name="description" cols="30" rows="3" class="form-control" value="" id="edit_project_description"></textarea>
          </div>
          
          <!-- Roles -->
          <div class="form-group mb-3">
            <label for="">Role</label>
            <select id="edit_project_role" class="form-control" name="role"></select>
          </div>
          
          <!-- Users -->
          <div class="form-group mb-3">
            <label for="">Users</label>
            <select id="edit_project_user" class="form-control" name="user"></select>
          </div>
          
          <!-- Client Profile -->
          <div class="form-group mb-3">
            <label for="">Profile</label>
            <input type="file" name="client_profile" id="update_client_profile" value="" class="form-control">
            <input type="hidden" name="client_old_profile" id="client_old_profile" value="">
          </div>

          <!-- Project id -->
          <input type="hidden" name="edit_project_id" id="edit_project_id" value="">
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <!--<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
          <input type="submit" class="btn btn-sm btn-outline-primary" value="Update">
        </div>
        
      </form>
    </div>
  </div>
</div>
<!-- edit modal ends -->


<!-- Delete client confirm modal -->
<div class="modal" tabindex="-1" id="confirm-delete-client-modal">
  <div class="modal-dialog">
    <div class="modal-content">
        <form action="<?php echo e(route('delete-project')); ?>" method='POST' class='form'>
            <?php echo csrf_field(); ?>
          <div class="modal-body">
            <p id='message_in_confirm_delete_client_modal'></p>
            <input type='hidden' name='id' id='id_in_confirm_delete_client_modal' value=''>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
          </div>
      </form>
    </div>
  </div>
</div>

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gbsprojects/public_html/taskmanagement/resources/views/projects.blade.php ENDPATH**/ ?>