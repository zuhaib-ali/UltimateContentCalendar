<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="container mt-5 pt-5">
<section id="second-container3">
        <div class="main-container-two">
          <div class="welcome-note-two">
            <h4>Projects, <?php echo e($projects->count()); ?></h4>
            <p>Projects list</p>
          </div>
          <div>
                <?php $__currentLoopData = json_decode(Session::get("user")->permissions_id, TRUE); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($per == 8): ?>
                    <button class="btn btn-success" data-bs-toggle="modal"  data-bs-target="#add_project" type="button">Add Project</button>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- Add user modal -->
                        <div class="modal" tabindex="-1" id="add_project">
                          <div class="modal-dialog">
                            <div class="modal-content">

                              <div class="modal-header">
                                <h5 class="modal-title">Add Project</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                              </div>
                              
                              <form action="<?php echo e(route('add-project')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="">
                                            <div class="mb-3">
                                                <input type="text" name="project_name" class="form-control" value="" id="first_name" placeholder="Project Name" required>
                                            </div>        
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="">
                                            <div class="mb-3">
                                                <textarea name="description" id="description" class="form-control" cols="30" rows="5" placeholder="Description"></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="">
                                            <div class="mb-3">
                                                <label for="deadline">Deadline</label>
                                                <input type="date" name="deadline" class="form-control" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- modal footer starts -->
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                  <input type="submit" class="btn btn-primary" value="Add">
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                        <!-- add user modal ends -->
          </div>


        </div>


        <!-- TABLES START -->
        <table class="table table-striped table-hover table-bordered">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Deadline</th>
              <th scope="col" style="width:130px;">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if($projects->count() == 0): ?>
            <tr >
                <td colspan="6">NO PROJECT FOUND!</td>
            </tr>
                
            <?php else: ?>
                <?php $no =1; ?>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($no++); ?></th>
                    <td><?php echo e($project->name); ?></td>
                    <td><?php echo e($project->deadline); ?></td>
                    <!-- <td><?php echo e($project->created_at->format("d M, y")); ?></td> -->

                    
                    <td>
                        <!-- View Project -->
                        <a href="#" class="me-3"><i class="far fa-eye" data-bs-toggle="modal" data-bs-target="#view_modal_<?php echo e($project->id); ?>"></i></a>
                        <div class="modal" tabindex="-1" id="view_modal_<?php echo e($project->id); ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">

                                    <div class="modal-header">
                                        <h5 class="modal-title"><?php echo e($project->name); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                          <p><b>Deadline</b> <?php echo e($project->deadline); ?></p>
                                        <p><?php echo e($project->description); ?></p>
                                    </div>

                                    <!-- Modal footer -->
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Edit modal -->
                        <?php if(Session::get("user")->role_id == 1): ?>
                        <a href="#" class="me-3"><i class="far fa-edit open" data-bs-toggle="modal" data-bs-target="#edit_modal_<?php echo e($project->id); ?>"></i></a>
                        <?php endif; ?>
                        <div class="modal" tabindex="-1" id="edit_modal_<?php echo e($project->id); ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">

                                    <div class="modal-header">
                                        <h5 class="modal-title">Edit <?php echo e($project->name); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                        
                                    <form action="<?php echo e(route('update-project')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">

                                            <!-- Project name -->
                                            <div class="form-group mb-3">
                                                <input type="text" placeholder="Project Name" name="project_name" value="<?php echo e($project->name); ?>" class="form-control">
                                            </div>

                                            <!-- Description -->
                                            <div class="form-group mb-3">
                                                <textarea name="description" id="" cols="30" rows="10" class="form-control"><?php echo e($project->description); ?></textarea>
                                            </div>

                                            <!-- Deadline -->
                                            <div class="form-group">
                                                <input type="date" name="deadline" value="<?php echo e($project->deadline); ?>" class="form-control">
                                            </div>

                                            <!-- Role id -->
                                            <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">
                                        </div>

                                        <!-- Modal footer -->
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <input type="submit" class="btn btn-primary" value="Update">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- edit modal ends -->

                        <!-- Delete -->
                        <?php if(Session::get("user")->role_id == 1): ?>
                        <a href="<?php echo e(route('delete-project', ['project_id' => $project->id])); ?>"><i class="far fa-trash" style="color:red;"></i></a>
                        <?php endif; ?>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </tbody>
        </table>
        <!-- TABLES END -->
      </section>
</main>

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskly\resources\views/projects.blade.php ENDPATH**/ ?>