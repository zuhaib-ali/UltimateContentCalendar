<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="container mt-5 pt-5">
    <!-- Manage role starts -->
    <section id="second-container">
    <input type="hidden" class="user_id" value="<?php echo e(Session::get('user')->id); ?>">
        <input type="hidden" class="role_id" value="<?php echo e(Session::get('user')->role_id); ?>">
        <div class="modal" tabindex="-1" id="view_task_detail">
            <div class="modal-dialog">
                <div class="modal-content">
                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <span class="task_title"></span>
                            <span class="view_task_label"></span>

                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <!-- Modal Body -->
                    <div class="modal-body">
                        <p class="d-flex justify-content-between">
                            <span><b>Deadline:</b></span>
                            <span class="deadline"></span>

                        </p>
                        <p>
                            <span><b>Description:</b></span><br>
                            <span class="desc"></span>
                        </p>

                        <h5>Attachments:</h5>
                        <div style="display:block" class="attData">

                            <div
                                style="border:1px solid lightgrey; padding:10px; margin:10px; display:flex; justify-content:space-between">
                                <div class="att"></div>
                                <a href="" class="btn-sm btn btn-success download">Download</a>
                            </div>

                        </div>
                    </div>

                    <!-- modal footer starts -->
                    <div class="modal-footer">
                        <?php if(Session::get('user')->role_id == 1): ?>

                            <a href="javascript:void(0)" class="btn btn-danger callRevine">Revine</a>
                            <a href="" class="btn btn-light approve" style="background-color: var(--approve-color); color:white;">Approve</a>
                            <label class="msg"
                                style="text-align:center; background-color: var(--approve-color); color:white; padding:5px; width:100%;">
                                Task Has Approved </label>
                                <label class="revinedd" style="text-align:center; background-color: var(--reject-color); color:white; padding:5px; width:100%;"> Task Has Revined </label>
                        <?php elseif(Session::get('user')->role_id != 1): ?>
                        <label class="msg"
                                style="text-align:center; background-color: var(--approve-color); color:white; padding:5px; width:100%;">
                                Task Approved </label>
                            <a href="" class="btn btn-light progres"
                                style="background-color:var(--in_progress-color); color:white;">In Progress</a>
                            <a href="" class="btn btn-light complete"
                                style="background-color:var(--complete-color); color:white;">Complete</a>
                        <?php endif; ?>

                        

                        

                        

                        
                    </div>

                    </form>
                </div>
            </div>
        </div>

        <div class="modal" tabindex="-1" id="revine_task_modal">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <h5 class="modal-title">Add Sub Task</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>

                    <form action="<?php echo e(route('task-revine')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">

                            <!-- Subject -->
                            <div class="row">
                                <div class="">
                                    <div class="mb-3">
                                        <input type="text" name="subject" class="form-control" value="" id="subject"
                                            placeholder="Subject" required>
                                    </div>
                                </div>
                            </div>

                            <!-- Description -->
                            <div class="row">
                                <div class="">
                                    <div class="mb-3">
                                        <textarea name="description" id="description" class="form-control" cols="30"
                                            rows="5" placeholder="Description"></textarea>
                                    </div>
                                </div>
                            </div>

                            <!-- Files -->
                            <div class="row">
                                <div class="">
                                    <div class="mb-3">
                                        <label for="deadline">Upload files</label>
                                        <input type="file" name="attachments[]" class="form-control" multiple>
                                    </div>
                                </div>
                            </div>

                            <!-- Task id -->
                            <input type="hidden" class="main_id" name="main_task_id" value="">

                            <!-- Subtask id -->
                            <input type="hidden" class="sub_task_id" name="sub_task_id" value="">
                        </div>


                        <!-- modal footer starts -->
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <input type="submit" class="btn btn-primary" value="Send">
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div>
                <h1 class="text-center">Task Calender</h1>
            </div>
            <div class="m-auto mt-4">
                <div class="container">
                    <div id='calendar'></div>
                </div>
            </div>

        </div>
    </section>
    
</main>



<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\taskly\resources\views/calender/calender.blade.php ENDPATH**/ ?>